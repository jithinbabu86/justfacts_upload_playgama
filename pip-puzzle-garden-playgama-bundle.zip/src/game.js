/* =========================================================================
   Pip's Puzzle Garden  —  prototype v0.3
   A cozy match-3 with a DAILY loop: play a round each day to earn that day's
   plant and grow your streak. Plus menu, How-to-Play, moves-based rounds with
   a results scorecard, best score, pause, a collection screen, and an in-game
   privacy statement.

   Built for YouTube Playables: fixed portrait canvas that scales to any
   screen (Scale.FIT), pointer input for touch AND mouse, responsive layout,
   and NO external network calls (Phaser bundled in /lib).
   ========================================================================= */

// ---- Tunable settings -----------------------------------------------------
const GAME_W = 720;
const GAME_H = 1280;
const COLS = 6;
const ROWS = 7;
const TILE = 104;
const BOARD_LEFT = (GAME_W - COLS * TILE) / 2;
const BOARD_TOP = 420;
const MOVES_PER_ROUND = 20;

const COLORS = [0xf4a7b9, 0x9bd7a8, 0xf7d774, 0x9cc4f0, 0xcba6e8, 0x8fd4c9];

const SWAP_DUR = 160;
const CLEAR_DUR = 200;
const DROP_DUR = 260;

// UI palette
const C_GREEN = 0x7cc48a, C_GREEN_DK = 0x5fae72;
const C_TAN = 0xd9a86c, C_TAN_DK = 0xc4945a;
const C_CREAM = 0xfffaf0;
const TXT_DARK = '#4a3f33';

// ---- Daily collection catalog --------------------------------------------
// Each plant: name, petal colour, centre colour, number of petals.
const PLANTS = [
  { name: 'Rosy Bloom',   color: 0xf4a7b9, center: 0xffe08a, petals: 6 },
  { name: 'Sun Daisy',    color: 0xf7d774, center: 0xe89b3c, petals: 8 },
  { name: 'Sky Aster',    color: 0x9cc4f0, center: 0xfff2c2, petals: 7 },
  { name: 'Mint Star',    color: 0x9bd7a8, center: 0xfff2c2, petals: 5 },
  { name: 'Lilac Puff',   color: 0xcba6e8, center: 0xffe08a, petals: 6 },
  { name: 'Coral Tulip',  color: 0xf6a06a, center: 0xfff2c2, petals: 5 },
  { name: 'Berry Bell',   color: 0xd98ac0, center: 0xffe08a, petals: 6 },
  { name: 'Teal Fern',    color: 0x7fd0c4, center: 0xfff2c2, petals: 7 },
  { name: 'Buttercup',    color: 0xffd95e, center: 0xe89b3c, petals: 6 },
  { name: 'Cloud Poppy',  color: 0xf3b6c6, center: 0xfff2c2, petals: 8 },
  { name: 'Dawn Iris',    color: 0xb0a6ec, center: 0xffe08a, petals: 5 },
  { name: 'Leaf Sprout',  color: 0x86c98f, center: 0xe8c33c, petals: 6 }
];

// ---- Save data (cross-session) -------------------------------------------
// Wrapped in try/catch so it degrades gracefully if storage is unavailable.
// At launch we'll swap localStorage for the Playables SDK's storage.
const Store = {
  data: { lastClaim: null, streak: 0, collected: [], best: 0, muted: false, totalFlowers: 0, level: 1 },
  load() {   // local-browser load (used when not inside YouTube Playables)
    try {
      const raw = localStorage.getItem('pip_save');
      if (raw) this.data = Object.assign(this.data, JSON.parse(raw));
    } catch (e) { /* storage blocked — fall back to in-memory only */ }
    return this.data;
  },
  fromString(v) {   // load from the SDK cloud save; value may be a JSON string OR an object
    try {
      const obj = (typeof v === 'string') ? JSON.parse(v) : v;
      if (obj && typeof obj === 'object') this.data = Object.assign(this.data, obj);
    } catch (e) { /* ignore */ }
  },
  save() {   // routes to Playgama Bridge storage (cloud) or localStorage locally
    Plat.save(JSON.stringify(this.data));
  }
};

// ---- Sound effects --------------------------------------------------------
// Synthesised with the Web Audio API — no audio files, no network, tiny size.
// (At launch we keep these as-is; they are self-contained.)
const Sfx = {
  ctx: null,
  muted: false,
  init() {
    if (!this.ctx) {
      try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); }
      catch (e) { /* audio unavailable */ }
    }
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
  },
  blip(freq, dur = 0.12, type = 'sine', vol = 0.18) {
    if (this.muted || !this.ctx) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type; o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.ctx.destination);
    o.start(t); o.stop(t + dur + 0.02);
  },
  pop(step = 0) { this.blip(520 + step * 70, 0.12, 'sine', 0.16); },
  swap() { this.blip(330, 0.09, 'triangle', 0.12); },
  tap() { this.blip(440, 0.05, 'square', 0.06); },
  chime() { [523, 659, 784].forEach((f, i) => setTimeout(() => this.blip(f, 0.32, 'sine', 0.14), i * 90)); },
  sparkle() { [880, 1175, 1568].forEach((f, i) => setTimeout(() => this.blip(f, 0.26, 'sine', 0.11), i * 70)); },
  formSpecial() { [660, 990].forEach((f, i) => setTimeout(() => this.blip(f, 0.16, 'triangle', 0.14), i * 70)); },
  trigger(kind) {
    if (kind === 'butterfly') [660, 880, 1100, 1320].forEach((f, i) => setTimeout(() => this.blip(f, 0.2, 'sine', 0.12), i * 60));
    else { this.blip(700, 0.16, 'square', 0.13); this.blip(950, 0.14, 'square', 0.1); }
  }
};
Sfx.muted = !!Store.data.muted;

// ---- Playgama Bridge SDK wrapper -----------------------------------------
// Thin, safe layer over the global `bridge`. Every call is guarded; when the
// SDK is absent (offline dev) it falls back to localStorage and grants rewards
// so the game runs identically in a plain browser. Bridge also mocks safely on
// unsupported platforms. Bridge already includes the YouTube bindings.
const Plat = {
  _reward: null,
  get available() { return typeof bridge !== 'undefined'; },
  async init() {
    if (!this.available) return;
    try {
      await bridge.initialize();
      // one rewarded-state listener resolves the pending reward promise
      bridge.advertisement.on(bridge.EVENT_NAME.REWARDED_STATE_CHANGED, (state) => {
        if (!this._reward) return;
        if (state === 'rewarded') { const r = this._reward; this._reward = null; r(true); }
        else if (state === 'closed' || state === 'failed') { const r = this._reward; this._reward = null; r(false); }
      });
    } catch (e) { console.warn('[Pip] bridge.initialize() failed, staying in fallback mode:', e); }
  },
  signalReady() { if (this.available) { try { bridge.platform.sendMessage('game_ready'); } catch (e) {} } },
  audioEnabled() { if (this.available) { try { return bridge.platform.isAudioEnabled !== false; } catch (e) {} } return true; },
  onAudioChange(cb) { if (this.available) { try { bridge.platform.on(bridge.EVENT_NAME.AUDIO_STATE_CHANGED, cb); } catch (e) {} } },
  onPauseChange(cb) { if (this.available) { try { bridge.platform.on(bridge.EVENT_NAME.PAUSE_STATE_CHANGED, cb); } catch (e) {} } },
  async load() {
    if (this.available) {
      try {
        const d = await bridge.storage.get(['save']);
        const v = Array.isArray(d) ? d[0] : (d && d.save);   // array or keyed object
        if (v !== undefined && v !== null) return v;
      } catch (e) { console.warn('[Pip] bridge.storage.get() failed:', e); }
    }
    return null;
  },
  save(str) {
    if (this.available) {
      // storage.set() returns a Promise per the Bridge docs and can reject --
      // must attach .catch() (fire-and-forget would drop async rejections
      // silently, AND skip the localStorage fallback below since we'd already
      // have returned before the rejection happened).
      try {
        bridge.storage.set(['save'], [str]).catch((e) => {
          console.warn('[Pip] bridge.storage.set() rejected, falling back to localStorage:', e);
          try { localStorage.setItem('pip_save', str); } catch (e2) {}
        });
        return;
      } catch (e) { console.warn('[Pip] bridge.storage.set() threw, falling back to localStorage:', e); }
    }
    try { localStorage.setItem('pip_save', str); } catch (e) {}
  },
  // Don't gate on isInterstitialSupported before calling — same reasoning as
  // rewarded(): Bridge's own initialInterstitialDelay already makes early
  // calls fail safely, so a local pre-check only risks silently skipping the
  // call a platform's test harness needs to see.
  interstitial() { if (this.available) { try { bridge.advertisement.showInterstitial(); } catch (e) {} } },
  setScore(v) { if (this.available) { try { bridge.leaderboards.setScore('best_garden', Math.max(0, Math.floor(v))); } catch (e) {} } },
  rewarded(placement) {
    return new Promise((resolve) => {
      if (!this.available) { resolve(true); return; }            // local dev: grant
      // Bridge's rewarded-ad API is a single global event stream with no
      // per-call id in REWARDED_STATE_CHANGED -- it only supports one flow
      // at a time. Starting a second showRewarded() while the first is still
      // pending let a late/stray event meant for one call resolve the OTHER
      // call's promise instead (a real ad network can report completion via
      // a server-side callback that lags behind the client UI closing) --
      // that cross-talk is what let an early close grant a reward, and a
      // real completion go ungranted. Refuse the overlap outright instead of
      // clobbering _reward, so only one request is ever pending.
      if (this._reward) { resolve(false); return; }
      try {
        // Always attempt the call — don't gate on isRewardedSupported. That flag
        // can be unset/stale when a platform's test harness is specifically
        // probing the rewarded-ad flow (e.g. an early-close simulation), and
        // gating here means we never call showRewarded at all, so the platform
        // never sees a call to intercept. Let the real response (state event,
        // thrown error, or timeout) decide success/failure instead.
        this._reward = resolve;
        bridge.advertisement.showRewarded(placement);
        setTimeout(() => { if (this._reward === resolve) { this._reward = null; resolve(false); } }, 60000);
      } catch (e) { this._reward = null; resolve(false); }
    });
  }
};

// interstitial frequency cap: show at most once per 2 completed rounds.
// Primed at 1 (not 0) so the very FIRST round-end already qualifies -- a cap
// that only ever kicks in on the second round means a single-round
// certification/QA test session would never see an interstitial attempt at
// all. Bridge's own minimumDelayBetweenInterstitial (config) handles the
// real-world pacing; this counter just avoids showing one on every round.
let _roundsSinceAd = 1;
function noteRoundEnd() { _roundsSinceAd++; }
async function maybeInterstitial() { if (_roundsSinceAd >= 2) { _roundsSinceAd = 0; Plat.interstitial(); } }

// Integer index of the local calendar day (for "today / yesterday" checks)
function dayIndex(date = new Date()) {
  return Math.floor((date.getTime() - date.getTimezoneOffset() * 60000) / 86400000);
}
function plantForDay(day) { return ((day % PLANTS.length) + PLANTS.length) % PLANTS.length; }
function claimedToday() { return Store.data.lastClaim === dayIndex(); }

// Award today's plant + update streak. Returns reward info, or null if already
// claimed today.
function claimDaily() {
  const today = dayIndex();
  const d = Store.data;
  if (d.lastClaim === today) return null;
  d.streak = (d.lastClaim === today - 1) ? d.streak + 1 : 1;
  d.lastClaim = today;
  const plant = plantForDay(today);
  if (!d.collected.includes(plant)) d.collected.push(plant);
  Store.save();
  return { plant, streak: d.streak };
}

// ---- Position helpers -----------------------------------------------------
function xFor(col) { return BOARD_LEFT + TILE / 2 + col * TILE; }
function yFor(row) { return BOARD_TOP + TILE / 2 + row * TILE; }
function randType(n = COLORS.length) { return Phaser.Math.Between(0, n - 1); }

// =========================================================================
// Reusable UI helpers
// =========================================================================
function makeButton(scene, x, y, w, h, label, onClick, opts = {}) {
  const base = opts.color ?? C_GREEN;
  const hover = opts.hover ?? C_GREEN_DK;
  const cont = scene.add.container(x, y);
  const bg = scene.add.graphics();
  const draw = (fill) => { bg.clear(); bg.fillStyle(fill, 1); bg.fillRoundedRect(-w / 2, -h / 2, w, h, 18); };
  draw(base);
  const txt = scene.add.text(0, 0, label, {
    fontFamily: 'Arial, sans-serif', fontSize: (opts.fontSize ?? 32) + 'px',
    fontStyle: 'bold', color: '#ffffff'
  }).setOrigin(0.5);
  // A transparent zone the exact size of the button is the click target. Using a
  // zone (not the container itself) gives a reliable, full-area hit box, and we
  // do NOT scale it on press, so edge clicks always register.
  const hit = scene.add.zone(0, 0, w, h).setInteractive({ useHandCursor: true });
  cont.add([bg, txt, hit]);
  cont.setSize(w, h);
  cont.hit = hit; cont.label = txt;
  hit.on('pointerover', () => draw(hover));
  hit.on('pointerout', () => draw(base));
  hit.on('pointerdown', () => draw(hover));
  hit.on('pointerup', () => { draw(base); Sfx.init(); Sfx.tap(); onClick(); });
  return cont;
}

// Small button whose label flips between Sound: On / Off
function makeSoundToggle(scene, x, y) {
  const label = () => (Store.data.muted ? 'Sound: Off' : 'Sound: On');
  const btn = makeButton(scene, x, y, 240, 64, label(), () => {
    Store.data.muted = !Store.data.muted;
    Sfx.muted = Store.data.muted;
    Store.save();
    btn.label.setText(label());
  }, { color: C_TAN, hover: C_TAN_DK, fontSize: 24 });
  return btn;
}

function makeOverlay(scene, title, bodyLines, opts = {}) {
  const w = 640, h = opts.h ?? 940;
  const cont = scene.add.container(GAME_W / 2, GAME_H / 2).setDepth(1000);
  const dim = scene.add.graphics();
  dim.fillStyle(0x000000, 0.55); dim.fillRect(-GAME_W / 2, -GAME_H / 2, GAME_W, GAME_H);
  const blocker = scene.add.zone(0, 0, GAME_W, GAME_H).setInteractive();
  const panel = scene.add.graphics();
  panel.fillStyle(C_CREAM, 1); panel.fillRoundedRect(-w / 2, -h / 2, w, h, 28);
  panel.lineStyle(6, C_GREEN, 1); panel.strokeRoundedRect(-w / 2, -h / 2, w, h, 28);
  const titleTxt = scene.add.text(0, -h / 2 + 56, title, {
    fontFamily: 'Arial, sans-serif', fontSize: '44px', fontStyle: 'bold', color: '#3c6e4b'
  }).setOrigin(0.5);
  const body = scene.add.text(-w / 2 + 40, -h / 2 + 120, bodyLines.join('\n\n'), {
    fontFamily: 'Arial, sans-serif', fontSize: '27px', color: TXT_DARK,
    wordWrap: { width: w - 80 }, lineSpacing: 8
  }).setOrigin(0, 0);
  const close = makeButton(scene, 0, h / 2 - 64, 280, 76, opts.closeLabel ?? 'Got it!', () => cont.setOpen(false));
  cont.add([dim, blocker, panel, titleTxt, body, close]);
  cont.setOpen = function (v) {
    this.setVisible(v);
    blocker.input.enabled = v;
    if (close.hit && close.hit.input) close.hit.input.enabled = v;
  };
  cont.setOpen(false);
  return cont;
}

// Collection screen — a grid of every plant; earned ones in colour, others grey.
function makeCollectionOverlay(scene) {
  const w = 660, h = 980;
  const cont = scene.add.container(GAME_W / 2, GAME_H / 2).setDepth(1000);
  const dim = scene.add.graphics();
  dim.fillStyle(0x000000, 0.55); dim.fillRect(-GAME_W / 2, -GAME_H / 2, GAME_W, GAME_H);
  const blocker = scene.add.zone(0, 0, GAME_W, GAME_H).setInteractive();
  const panel = scene.add.graphics();
  panel.fillStyle(C_CREAM, 1); panel.fillRoundedRect(-w / 2, -h / 2, w, h, 28);
  panel.lineStyle(6, C_GREEN, 1); panel.strokeRoundedRect(-w / 2, -h / 2, w, h, 28);
  cont.add([dim, blocker, panel]);

  cont.add(scene.add.text(0, -h / 2 + 56, 'My Collection', {
    fontFamily: 'Arial, sans-serif', fontSize: '44px', fontStyle: 'bold', color: '#3c6e4b'
  }).setOrigin(0.5));

  const have = Store.data.collected;
  cont.add(scene.add.text(0, -h / 2 + 108,
    have.length + ' / ' + PLANTS.length + ' plants grown', {
    fontFamily: 'Arial, sans-serif', fontSize: '26px', color: TXT_DARK
  }).setOrigin(0.5));

  const cols = 4, cellW = 150, cellH = 190, startX = -((cols - 1) * cellW) / 2, startY = -h / 2 + 250;
  PLANTS.forEach((p, i) => {
    const cx = startX + (i % cols) * cellW;
    const cy = startY + Math.floor(i / cols) * cellH;
    const owned = have.includes(i);
    cont.add(drawPlant(scene, cx, cy, i, 1.7, owned ? null : 0xcfcabf));
    cont.add(scene.add.text(cx, cy + 56, owned ? p.name : '???', {
      fontFamily: 'Arial, sans-serif', fontSize: '18px',
      color: owned ? TXT_DARK : '#a59f93', align: 'center',
      wordWrap: { width: cellW - 12 }
    }).setOrigin(0.5, 0));
  });

  const close = makeButton(scene, 0, h / 2 - 64, 280, 76, 'Close', () => cont.setOpen(false));
  cont.add(close);
  cont.setOpen = function (v) {
    this.setVisible(v);
    blocker.input.enabled = v;
    if (close.hit && close.hit.input) close.hit.input.enabled = v;
  };
  cont.setOpen(false);
  return cont;
}

// Draw a flower. `tint` (optional) overrides the colour, e.g. grey for "locked".
function drawPlant(scene, x, y, plantId, scale = 1, tint = null) {
  const p = PLANTS[plantId];
  const g = scene.add.graphics();
  const petals = p.petals;
  g.fillStyle(tint ?? p.color, 1);
  for (let i = 0; i < petals; i++) {
    const a = (i / petals) * Math.PI * 2;
    g.fillCircle(x + Math.cos(a) * 14 * scale, y + Math.sin(a) * 14 * scale, 9 * scale);
  }
  g.fillStyle(tint ? 0xb7b1a4 : p.center, 1);
  g.fillCircle(x, y, 10 * scale);
  return g;
}

// A collected plant growing from the ground, with a stem, leaves, and a gentle sway.
function plantInGarden(scene, x, groundY, plantId, scale, delay = 0) {
  const c = scene.add.container(x, groundY);
  const stemH = 70 * scale;
  const g = scene.add.graphics();
  g.lineStyle(6 * scale, 0x5aa06a, 1);
  g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -stemH); g.strokePath();
  g.fillStyle(0x6bbf7a, 1);
  g.fillEllipse(-11 * scale, -stemH * 0.5, 22 * scale, 12 * scale);
  g.fillEllipse(11 * scale, -stemH * 0.72, 22 * scale, 12 * scale);
  c.add(g);
  c.add(drawPlant(scene, 0, -stemH, plantId, 1.4 * scale));
  // grow-in: sprout up from the ground, then start a gentle sway
  c.setScale(0);
  scene.tweens.add({ targets: c, scale: 1, duration: 520, delay, ease: 'Back.easeOut' });
  scene.tweens.add({ targets: c, angle: { from: -2.5, to: 2.5 }, duration: 1700 + Math.random() * 700, yoyo: true, repeat: -1, ease: 'Sine.easeInOut', delay: delay + 520 });
  return c;
}

// An empty plot — a little soil mound with a tiny sprout, inviting a new plant.
function emptyPlot(scene, x, groundY, scale) {
  const g = scene.add.graphics();
  g.fillStyle(0x9c7a52, 1); g.fillEllipse(x, groundY, 44 * scale, 15 * scale);
  g.fillStyle(0x7cc48a, 1);
  g.fillEllipse(x - 6 * scale, groundY - 11 * scale, 11 * scale, 6 * scale);
  g.fillEllipse(x + 6 * scale, groundY - 11 * scale, 11 * scale, 6 * scale);
  return g;
}

function drawPip(scene, x, y, s = 1) {
  const g = scene.add.graphics();
  g.fillStyle(0x7cc48a, 1); g.fillCircle(x, y, 30 * s);
  g.fillStyle(0x3c6e4b, 1);
  g.fillEllipse(x - 10 * s, y - 34 * s, 22 * s, 14 * s);
  g.fillEllipse(x + 10 * s, y - 34 * s, 22 * s, 14 * s);
  g.fillStyle(0xffffff, 1);
  g.fillCircle(x - 9 * s, y - 2 * s, 7 * s); g.fillCircle(x + 9 * s, y - 2 * s, 7 * s);
  g.fillStyle(0x2b2233, 1);
  g.fillCircle(x - 9 * s, y - 2 * s, 3 * s); g.fillCircle(x + 9 * s, y - 2 * s, 3 * s);
  return g;
}

// Shared text ---------------------------------------------------------------
const HOW_TO_LINES = [
  '1.  Tap a bud to pick it up — a white ring shows it is selected.',
  '2.  Tap a bud right next to it to swap the two.',
  '3.  Line up 3 or more of the same colour, across or down. They bloom and your garden grows!',
  '4.  Buds above tumble down to fill the gaps — chains can bloom in a row for bonus growth.',
  '5.  Match 4 in a row to grow a Bee bud — matching it again clears its whole row or column!',
  '6.  Match 5, or an L or T shape, to grow a Butterfly bud — matching it clears every bud of that colour!',
  '7.  A swap that makes no match swaps back, and does not cost a move.',
  'Finish a round each day to earn that day’s plant and grow your daily streak!'
];
const PRIVACY_LINES = [
  'Pip’s Puzzle Garden is made to be safe and friendly for everyone, including children.',
  '•  We do not collect, store, or share any personal information.',
  '•  No sign-in or account is needed to play.',
  '•  We never ask for your name, email, location, photos, or contacts.',
  '•  Your progress is saved only on your own device, never sent anywhere.',
  '•  There is no chat and no links to other websites inside the game.',
  '•  Any ads are provided and controlled by YouTube under YouTube’s policies; the game runs no ads or trackers of its own.'
];

// =========================================================================
// BOOT SCENE — SDK handshake, load save data, then hand off to the menu
// =========================================================================
class BootScene extends Phaser.Scene {
  constructor() { super('BootScene'); }

  create() {
    const g = this.add.graphics();
    g.fillStyle(0xdff3e6, 1); g.fillRect(0, 0, GAME_W, GAME_H);
    drawPip(this, GAME_W / 2, GAME_H / 2 - 60, 2.2);
    this.add.text(GAME_W / 2, GAME_H / 2 + 90, 'Loading…', {
      fontFamily: 'Arial, sans-serif', fontSize: '34px', color: '#3c6e4b'
    }).setOrigin(0.5);

    const game = this.game;
    (async () => {
      await Plat.init();
      Plat.onAudioChange((enabled) => { Sfx.muted = !enabled; });
      Plat.onPauseChange((isPaused) => {
        if (isPaused) { Store.save(); if (game.scene.isActive('GardenScene')) game.scene.pause('GardenScene'); }
        else if (game.scene.isPaused('GardenScene')) game.scene.resume('GardenScene');
      });
      const s = await Plat.load();
      if (s) Store.fromString(s); else Store.load();
      Sfx.muted = !!Store.data.muted;      // user preference; Bridge audio events sync it later
      Store.save();                        // initial save so storage is written at least once
      this.scene.start('MenuScene');
      Plat.signalReady();                  // sends 'game_ready'
    })();
    // extra safety: persist when the page is hidden (covers quick reloads)
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') Store.save();
    });
  }
}

// =========================================================================
// MENU SCENE
// =========================================================================
class MenuScene extends Phaser.Scene {
  constructor() { super('MenuScene'); }

  create() {
    const g = this.add.graphics();
    g.fillStyle(0xdff3e6, 1); g.fillRect(0, 0, GAME_W, GAME_H);
    g.fillStyle(0xb98a5e, 1); g.fillRect(0, GAME_H - 90, GAME_W, 90);

    drawPip(this, GAME_W / 2, 230, 2.1);
    this.add.text(GAME_W / 2, 360, "Pip's", { fontFamily: 'Arial, sans-serif', fontSize: '62px', fontStyle: 'bold', color: '#3c6e4b' }).setOrigin(0.5);
    this.add.text(GAME_W / 2, 428, 'Puzzle Garden', { fontFamily: 'Arial, sans-serif', fontSize: '62px', fontStyle: 'bold', color: '#3c6e4b' }).setOrigin(0.5);

    this.drawDailyCard(GAME_W / 2, 620);

    makeButton(this, GAME_W / 2, 790, 360, 92, '▶  Play', () => this.scene.start('GardenScene'), { fontSize: 40 });

    // 2x2 grid of secondary buttons (My Garden highlighted in green)
    makeButton(this, 195, 892, 250, 76, 'My Garden', () => this.scene.start('GardenViewScene'), { color: C_GREEN, hover: C_GREEN_DK, fontSize: 26 });
    makeButton(this, 525, 892, 250, 76, 'How to Play', () => this.help.setOpen(true), { color: C_TAN, hover: C_TAN_DK, fontSize: 26 });
    makeButton(this, 195, 970, 250, 76, 'Collection', () => this.collection.setOpen(true), { color: C_TAN, hover: C_TAN_DK, fontSize: 26 });
    makeButton(this, 525, 970, 250, 76, 'Privacy', () => this.privacy.setOpen(true), { color: C_TAN, hover: C_TAN_DK, fontSize: 26 });

    this.add.text(GAME_W / 2, 1042, 'Best garden: ' + Store.data.best + '     Level ' + (Store.data.level || 1), {
      fontFamily: 'Arial, sans-serif', fontSize: '30px', color: '#5a4a3a'
    }).setOrigin(0.5);

    makeSoundToggle(this, GAME_W / 2, 1102);
    this.input.once('pointerdown', () => Sfx.init());

    this.help = makeOverlay(this, 'How to Play', HOW_TO_LINES);
    this.privacy = makeOverlay(this, 'Privacy', PRIVACY_LINES, { h: 880 });
    this.collection = makeCollectionOverlay(this);
  }

  drawDailyCard(cx, cy) {
    const w = 580, h = 230;
    const panel = this.add.graphics();
    panel.fillStyle(0xffffff, 0.65); panel.fillRoundedRect(cx - w / 2, cy - h / 2, w, h, 24);
    panel.lineStyle(4, C_GREEN, 0.8); panel.strokeRoundedRect(cx - w / 2, cy - h / 2, w, h, 24);

    const today = dayIndex();
    const plant = plantForDay(today);
    const done = claimedToday();

    this.add.text(cx, cy - h / 2 + 34, "Today's plant", {
      fontFamily: 'Arial, sans-serif', fontSize: '30px', fontStyle: 'bold', color: '#3c6e4b'
    }).setOrigin(0.5);

    drawPlant(this, cx - 150, cy + 30, plant, 2.4, done ? null : 0xcfcabf);
    this.add.text(cx - 150, cy + 86, done ? PLANTS[plant].name : 'Play to reveal!', {
      fontFamily: 'Arial, sans-serif', fontSize: done ? '22px' : '21px',
      fontStyle: done ? 'normal' : 'bold', color: done ? TXT_DARK : '#c4945a'
    }).setOrigin(0.5);

    this.add.text(cx + 70, cy - 20, 'Day streak', { fontFamily: 'Arial, sans-serif', fontSize: '26px', color: '#5a4a3a' }).setOrigin(0.5);
    this.add.text(cx + 70, cy + 22, String(Store.data.streak), { fontFamily: 'Arial, sans-serif', fontSize: '64px', fontStyle: 'bold', color: '#3c6e4b' }).setOrigin(0.5);
    this.add.text(cx + 70, cy + 70, done ? 'earned today ✓' : 'play to earn!', {
      fontFamily: 'Arial, sans-serif', fontSize: '22px', color: done ? '#5fae72' : '#c4945a'
    }).setOrigin(0.5);
  }
}

// =========================================================================
// GAME SCENE
// =========================================================================
class GardenScene extends Phaser.Scene {
  constructor() { super('GardenScene'); }

  create() {
    this.grid = [];
    this.score = 0;
    this.flowers = 0;
    this.movesLeft = MOVES_PER_ROUND;
    this.isBusy = false;
    this.paused = false;
    this.roundOver = false;
    this.selected = null;

    // level & goal for this round (harder gardens as you progress).
    // Goal numbers are tuned from a 5,000-round auto-player simulation:
    // casual play scores a median ~1,100 with 5 colours and ~880 with 6.
    // Levels 1-3 use 5 colours; level 4+ adds a 6th (lower scores), so the
    // goal steps down at the colour change to stay fair, then climbs again.
    this.level = Store.data.level || 1;
    this.nColors = Math.min(5 + Math.floor((this.level - 1) / 3), COLORS.length);
    this.goal = (this.level <= 3)
      ? 850 + (this.level - 1) * 120       // L1 850, L2 970, L3 1090  (5 colours)
      : 900 + (this.level - 4) * 90;       // L4 900, L5 990, L6 1080… (6 colours)
    this.goalMet = false;

    this.drawBackground();
    this.drawHud();
    this.buildGoalUI();
    this.selGfx = this.add.graphics();
    this.cascade = 0;
    this.setupParticles();
    this.buildBoard();
    this.input.once('pointerdown', () => Sfx.init());

    Store.save();                          // persist on round start (detectable save)
    this.buildQuitConfirm();
    this.help = makeOverlay(this, 'How to Play', HOW_TO_LINES);

    const hint = this.add.text(GAME_W / 2, BOARD_TOP - 30, 'Match 3 buds to bloom!', {
      fontFamily: 'Arial, sans-serif', fontSize: '30px', fontStyle: 'bold', color: '#3c6e4b'
    }).setOrigin(0.5).setDepth(900);
    this.tweens.add({ targets: hint, alpha: 0, delay: 1800, duration: 900, onComplete: () => hint.destroy() });
  }

  drawBackground() {
    const g = this.add.graphics();
    g.fillStyle(0xdff3e6, 1); g.fillRect(0, 0, GAME_W, GAME_H);
    g.fillStyle(0xc7e8d2, 1);
    g.fillRoundedRect(BOARD_LEFT - 18, BOARD_TOP - 18, COLS * TILE + 36, ROWS * TILE + 36, 28);
    g.fillStyle(0xb98a5e, 1); g.fillRect(0, GAME_H - 70, GAME_W, 70);
  }

  // One reusable particle emitter per bud colour, for bloom bursts on a match
  setupParticles() {
    if (!this.textures.exists('spark')) {
      const gg = this.make.graphics({ add: false });
      gg.fillStyle(0xffffff, 1); gg.fillCircle(8, 8, 8);
      gg.generateTexture('spark', 16, 16); gg.destroy();
    }
    this.emitters = COLORS.map((col) =>
      this.add.particles(0, 0, 'spark', {
        speed: { min: 90, max: 240 }, angle: { min: 0, max: 360 },
        scale: { start: 0.85, end: 0 }, alpha: { start: 1, end: 0 },
        lifespan: 550, gravityY: 320, quantity: 1, tint: col, emitting: false
      }).setDepth(50)
    );
  }

  burstAt(type, x, y) {
    if (this.emitters && this.emitters[type]) this.emitters[type].emitParticleAt(x, y, 7);
  }

  drawHud() {
    const M = 40;

    // soft header band (taller now that controls sit below the top edge)
    const hb = this.add.graphics();
    hb.fillStyle(0xffffff, 0.45);
    hb.fillRoundedRect(-40, -60, GAME_W + 80, 400, 30);
    hb.lineStyle(3, C_GREEN, 0.5);
    hb.beginPath(); hb.moveTo(0, 340); hb.lineTo(GAME_W, 340); hb.strokePath();

    // top row is TEXT ONLY — the very top corners are left clear so they don't
    // collide with YouTube's own close / mute / menu chrome.
    this.movesText = this.add.text(GAME_W / 2, 66, 'Moves: ' + this.movesLeft, {
      fontFamily: 'Arial, sans-serif', fontSize: '44px', fontStyle: 'bold', color: '#3c6e4b'
    }).setOrigin(0.5);
    this.scoreText = this.add.text(M, 124, 'Garden: 0', {
      fontFamily: 'Arial, sans-serif', fontSize: '30px', color: TXT_DARK
    }).setOrigin(0, 0.5);
    this.bestText = this.add.text(GAME_W - M, 124, 'Best: ' + Store.data.best, {
      fontFamily: 'Arial, sans-serif', fontSize: '30px', color: TXT_DARK
    }).setOrigin(1, 0.5);

    // control buttons as a centred pair, well below the top corners
    makeButton(this, 268, 192, 168, 72, '‹ Menu', () => this.confirmQuit(),
      { color: C_TAN, hover: C_TAN_DK, fontSize: 28 });
    makeButton(this, 452, 192, 74, 72, '?', () => this.help.setOpen(true),
      { color: C_TAN, hover: C_TAN_DK, fontSize: 38 });
  }

  updateHud() {
    this.movesText.setText('Moves: ' + Math.max(0, this.movesLeft));
    this.scoreText.setText('Garden: ' + this.score);
    this.bestText.setText('Best: ' + Math.max(Store.data.best, this.score));
    this.updateGoalBar();
    if (!this.goalMet && this.score >= this.goal) {
      this.goalMet = true;
      this.updateGoalBar();
      this.floatGoalReached();
      Sfx.sparkle();
    }
  }

  buildGoalUI() {
    this.add.text(40, 264, 'Level ' + this.level, {
      fontFamily: 'Arial, sans-serif', fontSize: '26px', fontStyle: 'bold', color: '#3c6e4b'
    }).setOrigin(0, 0.5);
    this.add.text(GAME_W - 40, 264, 'Goal: ' + this.goal, {
      fontFamily: 'Arial, sans-serif', fontSize: '26px', color: '#c4945a'
    }).setOrigin(1, 0.5);
    this._bar = { bx: 40, bw: GAME_W - 80, by: 300, bh: 26 };
    const bg = this.add.graphics();
    bg.fillStyle(0xffffff, 0.5); bg.fillRoundedRect(this._bar.bx, this._bar.by, this._bar.bw, this._bar.bh, 13);
    this.goalBarFill = this.add.graphics();
    this.updateGoalBar();
  }

  updateGoalBar() {
    if (!this.goalBarFill) return;
    const { bx, bw, by, bh } = this._bar;
    const frac = Math.min(1, this.score / this.goal);
    this.goalBarFill.clear();
    this.goalBarFill.fillStyle(this.goalMet ? 0xf7d774 : 0x7cc48a, 1);
    if (frac > 0) this.goalBarFill.fillRoundedRect(bx, by, Math.max(bh, bw * frac), bh, 13);
  }

  floatGoalReached() {
    const t = this.add.text(GAME_W / 2, 360, 'Goal reached!', {
      fontFamily: 'Arial, sans-serif', fontSize: '36px', fontStyle: 'bold', color: '#e8a33c'
    }).setOrigin(0.5).setDepth(800);
    this.tweens.add({ targets: t, y: 320, alpha: 0, scale: 1.3, duration: 1300, ease: 'Cubic.easeOut', onComplete: () => t.destroy() });
  }

  buildBoard() {
    for (let r = 0; r < ROWS; r++) {
      this.grid[r] = [];
      for (let c = 0; c < COLS; c++) this.grid[r][c] = this.makeTile(r, c, this.safeType(r, c));
    }
  }

  safeType(r, c) {
    let t;
    do { t = randType(this.nColors); } while (
      (c >= 2 && this.grid[r][c - 1].type === t && this.grid[r][c - 2].type === t) ||
      (r >= 2 && this.grid[r - 1][c].type === t && this.grid[r - 2][c].type === t)
    );
    return t;
  }

  makeTile(r, c, type) {
    const cont = this.add.container(xFor(c), yFor(r));
    const g = this.add.graphics();
    cont.add(g);
    cont.setSize(TILE, TILE);
    cont.setInteractive(new Phaser.Geom.Rectangle(-TILE / 2, -TILE / 2, TILE, TILE), Phaser.Geom.Rectangle.Contains);
    const tile = { r, c, type, special: null, obj: cont, gfx: g };
    this.paintTile(tile);
    cont.on('pointerdown', () => this.onTap(tile));
    return tile;
  }

  paintTile(tile) {
    const s = TILE - 14, base = COLORS[tile.type], g = tile.gfx;
    g.clear();
    g.fillStyle(base, 1); g.fillRoundedRect(-s / 2, -s / 2, s, s, 22);
    g.fillStyle(0xffffff, 0.40); g.fillCircle(0, 0, s * 0.26);
    g.fillStyle(base, 1); g.fillCircle(0, 0, s * 0.17);
    if (tile.special) this.drawSpecialIcon(g, s, tile.special);
  }

  // Bee bud (from a 4-match): stripes show the row/column it will clear.
  // Butterfly bud (from a 5-match or L/T shape): clears every bud of its colour.
  drawSpecialIcon(g, s, special) {
    if (special.kind === 'bee') {
      g.fillStyle(0xffffff, 0.85);
      if (special.axis === 'h') {
        g.fillRoundedRect(-s / 2 + 6, -7, s - 12, 5, 3);
        g.fillRoundedRect(-s / 2 + 6, 7, s - 12, 5, 3);
      } else {
        g.fillRoundedRect(-7, -s / 2 + 6, 5, s - 12, 3);
        g.fillRoundedRect(7, -s / 2 + 6, 5, s - 12, 3);
      }
      g.fillStyle(0xffd95e, 1); g.fillEllipse(0, 0, 22, 15);
      g.fillStyle(0x3a3226, 1); g.fillRect(-9, -7, 4, 14); g.fillRect(1, -7, 4, 14);
      g.fillStyle(0xffffff, 0.85); g.fillEllipse(-7, -10, 13, 8); g.fillEllipse(7, -10, 13, 8);
    } else if (special.kind === 'butterfly') {
      g.fillStyle(0xffffff, 0.92);
      g.fillEllipse(-10, -3, 16, 21); g.fillEllipse(10, -3, 16, 21);
      g.fillStyle(0xffffff, 0.6);
      g.fillEllipse(-9, 9, 10, 12); g.fillEllipse(9, 9, 10, 12);
      g.fillStyle(0x4a3f33, 1); g.fillEllipse(0, 0, 4, 20);
    }
  }

  onTap(tile) {
    if (this.isBusy || this.paused || this.roundOver) return;
    if (!this.selected) this.select(tile);
    else if (this.selected === tile) this.deselect();
    else if (this.adjacent(this.selected, tile)) { const a = this.selected; this.deselect(); this.trySwap(a, tile); }
    else this.select(tile);
  }

  select(tile) {
    this.clearPulse();
    this.selected = tile;
    this.selGfx.clear();
    this.selGfx.lineStyle(6, 0xffffff, 0.95);
    this.selGfx.strokeRoundedRect(xFor(tile.c) - TILE / 2 + 4, yFor(tile.r) - TILE / 2 + 4, TILE - 8, TILE - 8, 22);
    this.selTween = this.tweens.add({ targets: tile.obj, scale: 1.09, duration: 380, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
  }
  clearPulse() {
    if (this.selTween) { this.selTween.stop(); this.selTween = null; }
    if (this.selected && this.selected.obj && this.selected.obj.active) this.selected.obj.setScale(1);
  }
  deselect() { this.clearPulse(); this.selected = null; this.selGfx.clear(); }
  adjacent(a, b) { return Math.abs(a.r - b.r) + Math.abs(a.c - b.c) === 1; }

  trySwap(a, b) {
    this.isBusy = true;
    Sfx.init(); Sfx.swap();
    this.swapTiles(a, b);
    this.time.delayedCall(SWAP_DUR + 10, () => {
      if (this.findMatches().length > 0) {
        this.cascade = 0;
        this.movesLeft--; this.updateHud();
        this.lastSwapTiles = [a, b];
        this.resolveMatches();
      } else {
        Sfx.blip(220, 0.1, 'sine', 0.08);     // soft "nope"
        this.swapTiles(a, b);
        this.time.delayedCall(SWAP_DUR + 10, () => { this.isBusy = false; });
      }
    });
  }

  swapTiles(a, b) {
    const ar = a.r, ac = a.c, br = b.r, bc = b.c;
    this.grid[ar][ac] = b; this.grid[br][bc] = a;
    a.r = br; a.c = bc; b.r = ar; b.c = ac;
    this.tweens.add({ targets: a.obj, x: xFor(a.c), y: yFor(a.r), duration: SWAP_DUR });
    this.tweens.add({ targets: b.obj, x: xFor(b.c), y: yFor(b.r), duration: SWAP_DUR });
  }

  findMatches() {
    const set = new Set();
    for (let r = 0; r < ROWS; r++) {
      let c = 0;
      while (c < COLS) {
        const t = this.grid[r][c];
        if (!t) { c++; continue; }
        let run = 1;
        while (c + run < COLS && this.grid[r][c + run] && this.grid[r][c + run].type === t.type) run++;
        if (run >= 3) for (let k = 0; k < run; k++) set.add(this.grid[r][c + k]);
        c += run;
      }
    }
    for (let c = 0; c < COLS; c++) {
      let r = 0;
      while (r < ROWS) {
        const t = this.grid[r][c];
        if (!t) { r++; continue; }
        let run = 1;
        while (r + run < ROWS && this.grid[r + run][c] && this.grid[r + run][c].type === t.type) run++;
        if (run >= 3) for (let k = 0; k < run; k++) set.add(this.grid[r + k][c]);
        r += run;
      }
    }
    return Array.from(set);
  }

  // Like findMatches(), but groups matched tiles by connected run(s) and works
  // out whether each group should grow a special bud: a lone run of 4 grows a
  // Bee bud (clears its row/column); a run of 5+, or a run that crosses another
  // run (an L or T shape), grows a Butterfly bud (clears the whole colour).
  findMatchGroups() {
    const runs = [];
    for (let r = 0; r < ROWS; r++) {
      let c = 0;
      while (c < COLS) {
        const t = this.grid[r][c];
        if (!t) { c++; continue; }
        let run = 1;
        while (c + run < COLS && this.grid[r][c + run] && this.grid[r][c + run].type === t.type) run++;
        if (run >= 3) {
          const tiles = []; for (let k = 0; k < run; k++) tiles.push(this.grid[r][c + k]);
          runs.push({ axis: 'h', tiles, mid: tiles[Math.floor(tiles.length / 2)] });
        }
        c += run;
      }
    }
    for (let c = 0; c < COLS; c++) {
      let r = 0;
      while (r < ROWS) {
        const t = this.grid[r][c];
        if (!t) { r++; continue; }
        let run = 1;
        while (r + run < ROWS && this.grid[r + run][c] && this.grid[r + run][c].type === t.type) run++;
        if (run >= 3) {
          const tiles = []; for (let k = 0; k < run; k++) tiles.push(this.grid[r + k][c]);
          runs.push({ axis: 'v', tiles, mid: tiles[Math.floor(tiles.length / 2)] });
        }
        r += run;
      }
    }
    if (runs.length === 0) return [];

    // Union-find so runs that share a tile (an L/T shape) merge into one group.
    const parent = new Map();
    const find = (x) => { let root = x; while (parent.get(root) !== root) root = parent.get(root); return root; };
    const union = (a, b) => { const ra = find(a), rb = find(b); if (ra !== rb) parent.set(ra, rb); };
    runs.forEach((run) => run.tiles.forEach((t) => { if (!parent.has(t)) parent.set(t, t); }));
    runs.forEach((run) => { for (let i = 1; i < run.tiles.length; i++) union(run.tiles[0], run.tiles[i]); });
    const tileRuns = new Map();
    runs.forEach((run) => run.tiles.forEach((t) => {
      if (!tileRuns.has(t)) tileRuns.set(t, []);
      tileRuns.get(t).push(run);
    }));
    tileRuns.forEach((list) => { for (let i = 1; i < list.length; i++) union(list[0].tiles[0], list[i].tiles[0]); });

    const groupMap = new Map();
    runs.forEach((run) => {
      const root = find(run.tiles[0]);
      if (!groupMap.has(root)) groupMap.set(root, { tiles: new Set(), runs: [] });
      const g = groupMap.get(root);
      run.tiles.forEach((t) => g.tiles.add(t));
      g.runs.push(run);
    });

    return Array.from(groupMap.values()).map((g) => {
      const maxLen = Math.max(...g.runs.map((r) => r.tiles.length));
      const hasH = g.runs.some((r) => r.axis === 'h');
      const hasV = g.runs.some((r) => r.axis === 'v');
      let special = null;
      if ((hasH && hasV) || maxLen >= 5) special = { kind: 'butterfly' };
      else if (maxLen === 4) special = { kind: 'bee', axis: g.runs.find((r) => r.tiles.length === 4).axis };
      const longest = g.runs.slice().sort((a, b) => b.tiles.length - a.tiles.length)[0];
      return { tiles: Array.from(g.tiles), special, anchor: longest.mid };
    });
  }

  // A new special bud forms where the player's swap landed, if that tile is
  // part of the qualifying group; otherwise the middle of its longest run.
  pickPivot(gr) {
    if (this.lastSwapTiles) {
      const found = gr.tiles.find((t) => this.lastSwapTiles.includes(t));
      if (found) return found;
    }
    return gr.anchor;
  }

  // Tiles a special bud clears when it is triggered (matched or chained into).
  effectArea(tile) {
    if (!tile.special) return [];
    if (tile.special.kind === 'bee') {
      if (tile.special.axis === 'h') return this.grid[tile.r].filter((t) => t && t !== tile);
      const col = [];
      for (let r = 0; r < ROWS; r++) if (this.grid[r][tile.c]) col.push(this.grid[r][tile.c]);
      return col.filter((t) => t !== tile);
    }
    const out = [];
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
      const t = this.grid[r][c];
      if (t && t.type === tile.type && t !== tile) out.push(t);
    }
    return out;
  }

  floatText(x, y, text, color = '#3c6e4b') {
    const t = this.add.text(x, y, text, { fontFamily: 'Arial, sans-serif', fontSize: '26px', fontStyle: 'bold', color }).setOrigin(0.5);
    this.tweens.add({ targets: t, y: y - 60, alpha: 0, duration: 700, ease: 'Cubic.easeOut', onComplete: () => t.destroy() });
  }

  flashLine(r, c, axis) {
    const g = this.add.graphics().setDepth(40);
    g.fillStyle(0xffffff, 0.35);
    if (axis === 'h') g.fillRect(BOARD_LEFT, yFor(r) - TILE / 2, COLS * TILE, TILE);
    else g.fillRect(xFor(c) - TILE / 2, BOARD_TOP, TILE, ROWS * TILE);
    this.tweens.add({ targets: g, alpha: 0, duration: 340, onComplete: () => g.destroy() });
  }

  flashBoard(color) {
    const g = this.add.graphics().setDepth(40);
    g.fillStyle(color, 0.18);
    g.fillRoundedRect(BOARD_LEFT - 18, BOARD_TOP - 18, COLS * TILE + 36, ROWS * TILE + 36, 28);
    this.tweens.add({ targets: g, alpha: 0, duration: 450, onComplete: () => g.destroy() });
  }

  resolveMatches() {
    const groups = this.findMatchGroups();
    if (groups.length === 0) { this.isBusy = false; this.checkRoundEnd(); return; }

    // Decide which groups grow a new special bud (skip groups that already
    // contain one — those just trigger below instead of growing another).
    const pivots = new Map();
    const allMatched = new Set();
    groups.forEach((gr) => {
      gr.tiles.forEach((t) => allMatched.add(t));
      const alreadySpecial = gr.tiles.some((t) => t.special);
      if (gr.special && !alreadySpecial) pivots.set(this.pickPivot(gr), gr.special);
    });
    this.lastSwapTiles = null;

    const standard = new Set(allMatched);
    pivots.forEach((_, t) => standard.delete(t));

    // Chain: any special caught up in the clear pulls in its whole effect
    // area too (extra tiles score a bonus), which may itself contain more
    // specials — keep expanding until nothing new gets added.
    const toClear = new Set(standard);
    const bonus = new Set();
    const triggered = new Set();
    let changed = true;
    while (changed) {
      changed = false;
      toClear.forEach((t) => {
        if (t.special && !triggered.has(t)) {
          triggered.add(t);
          this.effectArea(t).forEach((at) => {
            if (!toClear.has(at) && !pivots.has(at)) { toClear.add(at); bonus.add(at); changed = true; }
          });
        }
      });
    }

    this.flowers += toClear.size;
    this.addScore(standard.size * 10 + bonus.size * 15);
    triggered.forEach((t) => {
      Sfx.trigger(t.special.kind);
      if (t.special.kind === 'bee') this.flashLine(t.r, t.c, t.special.axis);
      else this.flashBoard(COLORS[t.type]);
    });

    Sfx.pop(this.cascade);
    if (toClear.size >= 5 || this.cascade >= 1) this.cameras.main.shake(150, 0.004);
    this.cascade++;

    toClear.forEach((t) => {
      this.burstAt(t.type, xFor(t.c), yFor(t.r));
      this.floatScore(xFor(t.c), yFor(t.r), bonus.has(t) ? 15 : 10);
      this.tweens.add({ targets: t.obj, scale: 0, alpha: 0, duration: CLEAR_DUR, ease: 'Back.easeIn', onComplete: () => t.obj.destroy() });
      this.grid[t.r][t.c] = null;
    });

    pivots.forEach((special, t) => {
      t.special = special;
      this.paintTile(t);
      this.tweens.add({ targets: t.obj, scale: 1.35, duration: 180, yoyo: true, ease: 'Back.easeOut' });
      const isBig = special.kind === 'butterfly';
      this.addScore(isBig ? 90 : 40);
      this.floatText(xFor(t.c), yFor(t.r) - 50, isBig ? 'Butterfly bud!' : 'Bee bud!', '#c4945a');
      Sfx.formSpecial();
    });

    this.time.delayedCall(CLEAR_DUR + 30, () => {
      this.collapseAndRefill();
      this.time.delayedCall(DROP_DUR + 60, () => this.resolveMatches());
    });
  }

  collapseAndRefill() {
    for (let c = 0; c < COLS; c++) {
      const stack = [];
      for (let r = ROWS - 1; r >= 0; r--) if (this.grid[r][c]) stack.push(this.grid[r][c]);
      for (let r = 0; r < ROWS; r++) this.grid[r][c] = null;
      for (let i = 0; i < stack.length; i++) {
        const nr = ROWS - 1 - i, t = stack[i];
        t.r = nr; this.grid[nr][c] = t;
        this.tweens.add({ targets: t.obj, y: yFor(nr), duration: DROP_DUR, ease: 'Quad.easeIn' });
      }
      const empty = ROWS - stack.length;
      for (let nr = empty - 1; nr >= 0; nr--) {
        const t = this.makeTile(nr, c, randType(this.nColors));
        t.obj.y = yFor(nr) - empty * TILE - TILE;
        this.grid[nr][c] = t;
        this.tweens.add({ targets: t.obj, y: yFor(nr), duration: DROP_DUR, ease: 'Quad.easeIn' });
      }
    }
  }

  addScore(amount) {
    this.score += amount;
    this.updateHud();
    this.tweens.add({ targets: this.scoreText, scale: 1.12, duration: 90, yoyo: true });
  }

  floatScore(x, y, amount) {
    const t = this.add.text(x, y, '+' + amount, { fontFamily: 'Arial, sans-serif', fontSize: '30px', fontStyle: 'bold', color: '#3c6e4b' }).setOrigin(0.5);
    this.tweens.add({ targets: t, y: y - 60, alpha: 0, duration: 600, ease: 'Cubic.easeOut', onComplete: () => t.destroy() });
  }

  buildQuitConfirm() {
    this.quitOverlay = makeOverlay(this, 'Leave game?',
      ['You can come back any time — your best score and collection are saved.',
       'But quitting now ends this round without earning today’s plant.'],
      { h: 560, closeLabel: 'Keep playing' });

    // default close button = "Keep playing"; nudge it up to make room
    const keepBtn = this.quitOverlay.list[this.quitOverlay.list.length - 1];
    keepBtn.y = 118;

    const quitBtn = makeButton(this, 0, 208, 320, 76, 'Quit to menu',
      () => this.scene.start('MenuScene'), { color: C_TAN, hover: C_TAN_DK });
    this.quitOverlay.add(quitBtn);

    // extend setOpen so the quit button's input toggles with the overlay
    const baseOpen = this.quitOverlay.setOpen.bind(this.quitOverlay);
    this.quitOverlay.setOpen = (v) => {
      baseOpen(v);
      if (quitBtn.hit && quitBtn.hit.input) quitBtn.hit.input.enabled = v;
    };
    this.quitOverlay.setOpen(false);
  }

  confirmQuit() { this.quitOverlay.setOpen(true); }

  checkRoundEnd() {
    if (this.movesLeft <= 0 && !this.roundOver) {
      this.roundOver = true;
      this.leveledUp = false;
      if (this.goalMet) { this.level += 1; Store.data.level = this.level; this.leveledUp = true; }
      if (this.score > Store.data.best) Store.data.best = this.score;
      Store.data.totalFlowers = (Store.data.totalFlowers || 0) + this.flowers;
      Store.save();
      noteRoundEnd();
      Plat.setScore(Store.data.best);       // submit best score to the leaderboard
      const reward = claimDaily();          // award today's plant (or null if already done)
      this.time.delayedCall(300, () => this.showResults(reward));
    }
  }

  showResults(reward) {
    Sfx.chime();
    const w = 600, h = 900;
    const cont = this.add.container(GAME_W / 2, GAME_H / 2).setDepth(1100);
    const dim = this.add.graphics();
    dim.fillStyle(0x000000, 0.6); dim.fillRect(-GAME_W / 2, -GAME_H / 2, GAME_W, GAME_H);
    const blocker = this.add.zone(0, 0, GAME_W, GAME_H).setInteractive();
    const panel = this.add.graphics();
    panel.fillStyle(C_CREAM, 1); panel.fillRoundedRect(-w / 2, -h / 2, w, h, 28);
    panel.lineStyle(6, C_GREEN, 1); panel.strokeRoundedRect(-w / 2, -h / 2, w, h, 28);
    cont.add([dim, blocker, panel]);

    cont.add(this.add.text(0, -h / 2 + 56, 'Round complete!', {
      fontFamily: 'Arial, sans-serif', fontSize: '44px', fontStyle: 'bold', color: '#3c6e4b'
    }).setOrigin(0.5));

    const goalLine = this.goalMet
      ? (this.leveledUp ? '★ Goal reached — now Level ' + this.level + '!' : 'Goal reached!')
      : 'Goal was ' + this.goal + ' — so close, try again!';
    cont.add(this.add.text(0, -h / 2 + 148,
      goalLine + '\nGarden growth: ' + this.score + '\nFlowers bloomed: ' + this.flowers + '\nBest garden: ' + Store.data.best,
      { fontFamily: 'Arial, sans-serif', fontSize: '29px', color: this.goalMet ? '#3c6e4b' : TXT_DARK, align: 'center', lineSpacing: 6 }
    ).setOrigin(0.5));

    // Daily reward area
    if (reward) {
      const pc = this.add.container(0, 10);
      pc.add(drawPlant(this, 0, 0, reward.plant, 3.2));
      cont.add(pc);
      pc.setScale(0);
      this.tweens.add({ targets: pc, scale: 1, duration: 440, delay: 160, ease: 'Back.easeOut' });
      this.time.delayedCall(480, () => Sfx.sparkle());
      cont.add(this.add.text(0, 96, 'You earned today’s plant:\n' + PLANTS[reward.plant].name, {
        fontFamily: 'Arial, sans-serif', fontSize: '30px', fontStyle: 'bold', color: '#3c6e4b', align: 'center', lineSpacing: 4
      }).setOrigin(0.5));
      cont.add(this.add.text(0, 156, 'Day streak: ' + reward.streak, {
        fontFamily: 'Arial, sans-serif', fontSize: '32px', fontStyle: 'bold', color: '#c4945a'
      }).setOrigin(0.5));
    } else {
      cont.add(this.add.text(0, 70, 'You’ve already grown today’s plant.\nCome back tomorrow for a new one!', {
        fontFamily: 'Arial, sans-serif', fontSize: '28px', color: TXT_DARK, align: 'center', lineSpacing: 6
      }).setOrigin(0.5));
      cont.add(this.add.text(0, 156, 'Day streak: ' + Store.data.streak, {
        fontFamily: 'Arial, sans-serif', fontSize: '32px', fontStyle: 'bold', color: '#c4945a'
      }).setOrigin(0.5));
    }

    // Rewarded ad: an optional bonus plant for your collection
    const uncollected = PLANTS.map((_, i) => i).filter((i) => !Store.data.collected.includes(i));
    if (uncollected.length > 0) {
      const rw = makeButton(this, 0, 232, 400, 70, '🎁  Bonus plant', async () => {
        if (rw.hit && rw.hit.input) rw.hit.input.enabled = false;
        const earned = await Plat.rewarded('bonus-plant-v1');
        if (!earned) { if (rw.hit && rw.hit.input) rw.hit.input.enabled = true; return; }
        const pick = uncollected[Math.floor(Math.random() * uncollected.length)];
        if (!Store.data.collected.includes(pick)) { Store.data.collected.push(pick); Store.save(); }
        rw.destroy();
        const bp = this.add.container(0, 224); bp.add(drawPlant(this, 0, 0, pick, 2.0)); cont.add(bp);
        bp.setScale(0); this.tweens.add({ targets: bp, scale: 1, duration: 400, ease: 'Back.easeOut' });
        Sfx.sparkle();
        cont.add(this.add.text(0, 270, 'Got ' + PLANTS[pick].name + '!', {
          fontFamily: 'Arial, sans-serif', fontSize: '22px', color: '#3c6e4b'
        }).setOrigin(0.5));
      }, { color: C_GREEN, hover: C_GREEN_DK, fontSize: 26 });
      cont.add(rw);
    }

    cont.add(makeButton(this, 0, h / 2 - 134, 340, 84, '↻  Play again',
      async () => { await maybeInterstitial(); this.scene.restart(); }, { fontSize: 36 }));
    cont.add(makeButton(this, 0, h / 2 - 46, 340, 76, 'Main menu',
      async () => { await maybeInterstitial(); this.scene.start('MenuScene'); }, { color: C_TAN, hover: C_TAN_DK }));

    cont.setScale(0.8); cont.setAlpha(0);
    this.tweens.add({ targets: cont, scale: 1, alpha: 1, duration: 260, ease: 'Back.easeOut' });
  }
}

// =========================================================================
// GARDEN META-SCREEN — your collected plants growing in a garden
// =========================================================================
class GardenViewScene extends Phaser.Scene {
  constructor() { super('GardenViewScene'); }

  create() {
    const have = Store.data.collected;
    const total = Store.data.totalFlowers || 0;

    // scenery: sky, sun, grass, soil
    const g = this.add.graphics();
    g.fillStyle(0xdff3e6, 1); g.fillRect(0, 0, GAME_W, GAME_H);
    g.fillStyle(0xfff2c2, 0.5); g.fillCircle(GAME_W - 96, 150, 92);
    g.fillStyle(0xffe08a, 1); g.fillCircle(GAME_W - 96, 150, 62);
    g.fillStyle(0x9bd7a8, 1); g.fillRect(0, 820, GAME_W, GAME_H - 820);
    g.fillStyle(0x86c98f, 1); g.fillRect(0, 820, GAME_W, 10);
    g.fillStyle(0xb98a5e, 1); g.fillRect(0, GAME_H - 90, GAME_W, 90);

    // slowly rotating sun rays
    const rays = this.add.container(GAME_W - 96, 150);
    const rg = this.add.graphics(); rg.fillStyle(0xffe08a, 0.4);
    for (let i = 0; i < 12; i++) {
      const a = i * (Math.PI * 2 / 12), ux = Math.cos(a), uy = Math.sin(a), px = -Math.sin(a), py = Math.cos(a);
      const inner = 68, outer = 100, w = 7;
      rg.fillTriangle(ux * outer, uy * outer, ux * inner + px * w, uy * inner + py * w, ux * inner - px * w, uy * inner - py * w);
    }
    rays.add(rg);
    this.tweens.add({ targets: rays, angle: 360, duration: 70000, repeat: -1 });

    // drifting clouds + grass tufts
    this.addCloud(120, 1.0, 42000);
    this.addCloud(230, 0.7, 55000);
    const tufts = this.add.graphics(); tufts.fillStyle(0x6bbf7a, 1);
    for (let i = 0; i < 16; i++) {
      const gx = 20 + Math.random() * (GAME_W - 40), gy = 824 + Math.random() * 6;
      tufts.fillTriangle(gx, gy, gx - 5, gy - 16, gx - 1, gy);
      tufts.fillTriangle(gx + 2, gy, gx + 6, gy - 18, gx + 3, gy);
    }

    // header
    this.add.text(GAME_W / 2, 96, 'My Garden', {
      fontFamily: 'Arial, sans-serif', fontSize: '50px', fontStyle: 'bold', color: '#3c6e4b'
    }).setOrigin(0.5);
    this.add.text(GAME_W / 2, 156, have.length + ' / ' + PLANTS.length + ' kinds grown', {
      fontFamily: 'Arial, sans-serif', fontSize: '28px', color: TXT_DARK
    }).setOrigin(0.5);
    this.add.text(GAME_W / 2, 198, total + ' flowers bloomed so far', {
      fontFamily: 'Arial, sans-serif', fontSize: '24px', color: '#c4945a'
    }).setOrigin(0.5);

    if (have.length === 0) {
      this.add.text(GAME_W / 2, 470,
        'Your garden is waiting!\n\nPlay a round each day to earn plants\nand watch them bloom right here.', {
        fontFamily: 'Arial, sans-serif', fontSize: '30px', color: TXT_DARK, align: 'center', lineSpacing: 8
      }).setOrigin(0.5);
    }

    // plots: back row (plants 0-5) and front row (plants 6-11), staggered grow-in
    let d = 0;
    for (let i = 0; i < 6; i++) { this.placePlot(90 + i * 108, 930, i, 0.85, d); d += 70; }
    for (let i = 0; i < 6; i++) { this.placePlot(60 + i * 120, 1095, i + 6, 1.05, d); d += 70; }

    this.addButterfly();
    this.addBee();

    makeButton(this, 122, 74, 164, 74, '‹ Menu', () => this.scene.start('MenuScene'),
      { color: C_TAN, hover: C_TAN_DK, fontSize: 28 });

    this.input.once('pointerdown', () => Sfx.init());
  }

  placePlot(x, y, plantId, scale, delay) {
    if (Store.data.collected.includes(plantId)) plantInGarden(this, x, y, plantId, scale, delay);
    else emptyPlot(this, x, y, scale);
  }

  addCloud(y, s, dur) {
    const c = this.add.container(-160, y).setDepth(1);
    const g = this.add.graphics();
    g.fillStyle(0xffffff, 0.8);
    g.fillEllipse(0, 0, 80 * s, 44 * s);
    g.fillEllipse(-42 * s, 10 * s, 54 * s, 32 * s);
    g.fillEllipse(42 * s, 10 * s, 54 * s, 32 * s);
    c.add(g);
    this.tweens.add({ targets: c, x: GAME_W + 160, duration: dur, repeat: -1 });
  }

  addBee() {
    const b = this.add.container(GAME_W + 40, 600).setDepth(60);
    const g = this.add.graphics();
    g.fillStyle(0xf7d774, 1); g.fillEllipse(0, 0, 22, 15);
    g.fillStyle(0x4a3f33, 1); g.fillRect(-3, -7, 3, 14); g.fillRect(4, -7, 3, 14);
    g.fillStyle(0xffffff, 0.7); g.fillEllipse(-7, -9, 12, 8); g.fillEllipse(7, -9, 12, 8);
    b.add(g);
    this.tweens.add({ targets: b, x: -40, duration: 11000, repeat: -1, ease: 'Sine.easeInOut' });
    this.tweens.add({ targets: b, y: 500, duration: 1300, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
  }

  addButterfly() {
    const b = this.add.container(-40, 420).setDepth(60);
    const wings = this.add.graphics();
    wings.fillStyle(0xf3b6c6, 1); wings.fillEllipse(-8, 0, 16, 22); wings.fillEllipse(8, 0, 16, 22);
    wings.fillStyle(0x6a5a4a, 1); wings.fillEllipse(0, 0, 5, 20);
    b.add(wings);
    this.tweens.add({ targets: b, x: GAME_W + 40, duration: 9000, repeat: -1, ease: 'Sine.easeInOut' });
    this.tweens.add({ targets: b, y: 300, duration: 1600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    this.tweens.add({ targets: wings, scaleX: 0.55, duration: 170, yoyo: true, repeat: -1 });
  }
}

// =========================================================================
// Boot Phaser
// =========================================================================
const config = {
  type: Phaser.AUTO,
  parent: 'game',
  backgroundColor: '#dff3e6',
  scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH, width: GAME_W, height: GAME_H },
  scene: [BootScene, MenuScene, GardenScene, GardenViewScene]
};

new Phaser.Game(config);
