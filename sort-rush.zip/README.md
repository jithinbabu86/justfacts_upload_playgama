# Sort Rush

A mobile-first color-sorting puzzle built for the [Playgama](https://playgama.com) HTML5 platform. Tap a tube to pick up its top color, tap another to pour it in — sort every tube into a single solid color to clear the level. Endless, procedurally generated levels with a guaranteed-solvable puzzle generator, rewarded-ad hooks that are genuinely useful (never a paywall), and interstitials only at natural break points.

## Mobile-first philosophy

Every design decision here was made for a thumb on a phone, not a mouse on a desktop:

- **Pure tap controls** — no hover states, no keyboard, no precision timing. Select a tube, select another, done.
- **One-thumb portrait play** — the action bar sits where a thumb naturally rests; the canvas fills the space between HUD and action bar and re-lays-out tubes on rotation.
- **Short sessions** — a level is a 20–90 second loop; failure (a stuck board) is one tap from a fresh attempt, never a hard wall.
- **Zero image/audio assets** — everything is drawn on `<canvas>` and every sound is synthesized with the Web Audio API. This keeps the whole game under a few hundred KB (well under the 5MB budget) and sidesteps any asset licensing question entirely.
- **Ads that respect the player** — rewarded ads only ever grant a convenience (undo, hint, extra tube, bonus gems) with the reward shown on the button before they tap it; interstitials are capped to once every 3 minutes and only ever appear between levels.

## Project structure

```
index.html                     Markup, viewport/safe-area meta tags, loading/tutorial/game/overlay screens
playgama-bridge-config.json    Bridge SDK config bundled with the game itself (see SDK section below)
css/style.css                  Mobile-first layout, safe-area insets, no-scroll/no-zoom, thumb-sized targets
js/level.js                    Puzzle rules, procedural generator, A* solver (also powers hints)
js/render.js                   Canvas 2D rendering, glossy tube/liquid rendering, pour animation
js/icons.js                    Hand-authored inline SVG icon set (replaces emoji glyphs entirely)
js/particles.js                Object-pooled particle bursts (juice without per-frame GC churn)
js/audio.js                    Web Audio synthesized SFX, muted-by-default, iOS unlock-on-touch
js/haptics.js                  navigator.vibrate wrapper (best-effort — iOS Safari has no support)
js/storage.js                  Save/load via the Playgama Bridge storage module, localStorage fallback
js/sdk.js                      Playgama Bridge SDK wrapper (init, ads, lifecycle events, leaderboards)
js/main.js                     State machine, game loop, input, HUD, ad/undo/hint flows
```

No build step, no bundler, no framework — plain ES modules loaded directly by the browser.

## How to run locally

```bash
cd playgama_games
python3 -m http.server 8123
```

Then open `http://localhost:8123` in a browser.

### Testing on a real phone over your local network

1. Find your computer's LAN IP:
   - macOS: `ipconfig getifaddr en0`
   - Windows: `ipconfig` (look for "IPv4 Address")
2. Make sure your phone is on the **same Wi-Fi network**.
3. On your phone's browser, go to `http://<your-computer-ip>:8123`.
4. If it doesn't load, check your OS firewall isn't blocking incoming connections on port 8123.

For quicker iteration with Chrome DevTools remote debugging (Android) or Safari Web Inspector (iOS), connect the phone via USB and enable the respective developer/remote-inspection option — both let you see console output and inspect the live DOM from your desktop.

## Playgama SDK integration

Integrated against the real [`@playgama/bridge`](https://github.com/playgama/bridge) SDK (verified against its source — the platform's own docs sites returned 403s to automated fetches, so the integration here is grounded in the actual TypeScript source rather than assumed API shapes):

- Loaded via `<script src="https://cdn.jsdelivr.net/npm/@playgama/bridge@2/dist/playgama-bridge.umd.js">`. **Important gotcha found by testing against the live script, not assumed from docs:** the UMD build's own webpack wrapper reassigns the top-level `window.bridge` to the module's *exports namespace* (constants like `EVENT_NAME`, plus a nested `.bridge`/`.default`) — it clobbers the actual bridge singleton the module sets up internally. The real, working instance lives at `window.playgamaBridge`. `js/sdk.js`'s `getRealBridge()` checks `window.playgamaBridge` first for this reason; checking `window.bridge` first (as the SDK's own naming would suggest) silently resolves to the wrong object and falls back to the mock every time.
- `bridge.initialize()` on boot, `bridge.setGameLoadingProgress(percent)` during load. `initialize()` fetches `./playgama-bridge-config.json` (relative to the page, i.e. the game's own root - **this file is bundled with the game, not provided by the platform**; a "Bridge config file couldn't be loaded" warning on the real dashboard meant it was genuinely missing, not a platform-side issue). It's a no-op-if-missing fallback (game still runs standalone without it), but it's real and reachable now — see `playgama-bridge-config.json` at the project root. Currently just registers the leaderboard mapping (see below); other sections exist (`advertisement`, `achievements`, `payments`, `game.adaptToSafeArea`, etc. — full shape in `ConfigFileOptions` in the SDK source) if real ad-network/achievement IDs are ever needed.
- `bridge.leaderboards.setScore(id, score, isMain)` resolves the *platform-specific* leaderboard id and `isMain` flag from this same config file's `leaderboards: [{ id, isMain, <platformId>: '...' }]` array — `sortrush_highest_level` is registered there with `isMain: true`. If the dashboard-created leaderboard ends up with a different underlying id, add `"playgama": "<that-id>"` to the same config entry rather than changing `LEADERBOARD_ID` in `js/main.js`.
- `bridge.platform.sendMessage('game_ready')`, called once from `js/main.js`'s `boot()` right before the tutorial/game screen shows. **This one caused a real submission failure** ("game ready signal failed... did not send the readiness event") when first tested on `developer.playgama.com` — `setGameLoadingProgress`/`initialize()` alone are not the readiness signal the platform's review gate actually waits on; this distinct `sendMessage` call is. Confirmed the fix by causation-testing against the live CDN script: the SDK's own branding overlay div (injected into `document.body`, independent of our code) is documented to be removed specifically as part of handling `'game_ready'` — with the call removed, the overlay stayed forever (reproducing the exact reported symptom); with it restored, the overlay clears correctly.
- `bridge.advertisement.showRewarded(placement)` / `showInterstitial(placement)`, gated by `isRewardedSupported` / `isInterstitialSupported` and driven by the `rewarded_state_changed` / `interstitial_state_changed` events.
- `bridge.storage.get/set` for save data.
- `bridge.leaderboards.getEntries/showNativePopup`, gated by `bridge.leaderboards.type` (`'not_available' | 'in_game' | 'native' | 'native_popup'`) — the leaderboard button in the HUD stays hidden entirely when unavailable.
- `bridge.platform.on('pause_state_changed'/'audio_state_changed', ...)` **must be subscribed via `bridge.platform.on(...)` specifically** (confirmed against `wiki.playgama.com/playgama/bridge-sdk/api/platform`, which was reachable this time), with a plain boolean payload — not the object-shaped guess an earlier version of this file made. More importantly: **these events only fire on subsequent changes.** A game that starts already paused/muted (as `developer.playgama.com`'s review reported) would never see a "change" and would wrongly keep running/making sound. `js/sdk.js` now also reads `bridge.platform.isPaused`/`isAudioEnabled` once at boot and applies them immediately, in addition to subscribing for later changes. `js/audio.js` gates sound through a separate `platformMuted` flag so a platform-imposed mute can never be overridden by, or override, the player's own mute toggle.
- `bridge.platform.sendMessage('level_started'/'level_completed', { level })` — optional per the docs but recommended; sent from `loadLevel()`/`onLevelComplete()` in `js/main.js`.
- `pause_state_changed` event plus `document.visibilitychange`/`blur`/`focus` for lifecycle (app switch, screen lock, phone call interruption).
- If the CDN script fails to load (offline, blocked network) or the game runs outside the Playgama platform entirely, `js/sdk.js` falls back to a no-op mock bridge so the game is still fully playable standalone — ads just don't fire, and saves fall back to `localStorage`.

## Ad placement strategy

| Placement | Trigger | What the player gets | Type |
|---|---|---|---|
| `undo` | Tapping Undo after the 3 free undos are used | One extra undo | Rewarded |
| `hint` | Tapping Hint (always ad-gated) | The next correct move highlighted | Rewarded |
| `extra_tube` | Tapping Extra Tube | An additional empty tube added to the board | Rewarded |
| `double_reward` | Tapping "Watch Ad — +N Bonus" on the level-complete screen | Gems earned this level, doubled | Rewarded |
| `between_levels` | Tapping Next Level | — | Interstitial, min. 3-minute gap |

Design rules followed throughout: every rewarded placement shows the exact reward on the button before the player commits; a skipped/failed ad never removes anything the player already has (`showRewarded` resolves `false` and the UI just does nothing); interstitials never interrupt active gameplay, only the transition between levels, and are rate-limited both by `js/main.js` and by the SDK's own `setMinimumDelayBetweenInterstitial`.

## Leaderboard

Ranks players by highest level reached. Submitted via `bridge.leaderboards.setScore('sortrush_highest_level', level)` every time a level completes.

**This needs one manual step before it'll show real data:** create a leaderboard with the id `sortrush_highest_level` on the Playgama developer dashboard (or tell me the id if you've already created one under a different name, and I'll update `LEADERBOARD_ID` in `js/main.js` to match). Without a matching dashboard entry, `setScore`/`getEntries` calls are harmless no-ops.

The 🏆 button in the HUD only appears when `bridge.leaderboards.type !== 'not_available'` — hidden entirely in standalone/local testing and on any platform without leaderboard support. When the platform provides a native leaderboard UI (`type: 'native'`/`'native_popup'`), tapping the button opens that directly; otherwise it opens an in-game list built from `getEntries()`.

## Mobile testing checklist

- [x] Loads and plays with only tap input (no keyboard/hover dependency)
- [x] 44px+ touch targets on all buttons (`css/style.css` `.icon-btn`, `.action-btn`)
- [x] Portrait-primary responsive layout, adapts on `orientationchange`/`resize`
- [x] `env(safe-area-inset-*)` applied around the whole app shell
- [x] Pinch-zoom and pull-to-refresh disabled (`user-scalable=no`, `touch-action: none`, `overflow: hidden` + `position: fixed`)
- [x] Audio muted by default, unlocked on first touch, resumes after interruption (`resumeOnInterruptionEnd`)
- [x] Game pauses on tab hidden / blur and resumes on visible / focus
- [x] Haptic feedback on tap/pour/solve where `navigator.vibrate` is supported
- [x] Fast restart — one tap from a stuck board back into play
- [x] Zero image/audio asset downloads — synthesized audio, canvas-drawn visuals
- [ ] Verify on a physical iPhone (Safari) and Android device (Chrome/Samsung Internet) before submission — this was verified with headless Chromium at a 390×844 (iPhone-sized) viewport during development; a real-device pass is still recommended before shipping.

### Simulating mobile in the browser

Chrome DevTools → toggle device toolbar (Cmd/Ctrl+Shift+M) → pick an iPhone/Android preset → reload. Test both portrait and landscape, and throttle the network to "Slow 4G" to confirm the loading screen behaves.

## Supported platforms

- iOS Safari 15+
- Chrome for Android 10+
- Samsung Internet
- Any evergreen desktop browser (Chrome/Firefox/Safari/Edge) as a secondary, non-primary experience

## Known limitation / next step

Level generation runs synchronously (it's fast — under 20ms even at max difficulty in stress testing, so there's no visible hitch) but isn't offloaded to a Worker. If a future difficulty tier needs a much larger board, that's the first place to add async chunking.
