// Tiny synthesized SFX via Web Audio - keeps the game under budget with zero audio assets
// and no licensing concerns. Muted by default per platform rules; unlocked on first touch (iOS).

let ctx = null;
let muted = true;
// Separate from the player's own mute toggle - set when the Playgama platform signals
// audio should be off (e.g. a system overlay is showing). Combined with `muted` via OR
// so a platform-imposed mute never gets overridden by, or overrides, the user's own choice.
let platformMuted = false;

function ensureContext() {
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    ctx = new AC();
  }
  if (ctx.state === 'suspended') ctx.resume().catch(() => {});
  return ctx;
}

export function unlockAudio() {
  ensureContext();
}

export function setMuted(value) {
  muted = value;
}

export function isMuted() {
  return muted;
}

export function setPlatformMuted(value) {
  platformMuted = value;
}

function tone({ freq = 440, duration = 0.12, type = 'sine', gain = 0.2, glideTo = null } = {}) {
  if (muted || platformMuted) return;
  const c = ensureContext();
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, c.currentTime);
  if (glideTo) osc.frequency.exponentialRampToValueAtTime(glideTo, c.currentTime + duration);
  g.gain.setValueAtTime(gain, c.currentTime);
  g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + duration);
  osc.connect(g).connect(c.destination);
  osc.start();
  osc.stop(c.currentTime + duration + 0.02);
}

export const sfx = {
  pour: () => tone({ freq: 320, glideTo: 220, duration: 0.16, type: 'sine', gain: 0.18 }),
  select: () => tone({ freq: 520, duration: 0.06, type: 'triangle', gain: 0.12 }),
  invalid: () => tone({ freq: 140, duration: 0.14, type: 'square', gain: 0.1 }),
  tubeSolved: () => {
    tone({ freq: 660, duration: 0.1, type: 'sine', gain: 0.16 });
    setTimeout(() => tone({ freq: 880, duration: 0.14, type: 'sine', gain: 0.16 }), 80);
  },
  levelComplete: () => {
    [660, 880, 1100].forEach((f, i) => setTimeout(() => tone({ freq: f, duration: 0.18, type: 'sine', gain: 0.18 }), i * 90));
  },
  button: () => tone({ freq: 300, duration: 0.05, type: 'triangle', gain: 0.1 }),
  reward: () => {
    [520, 660, 780, 1040].forEach((f, i) => setTimeout(() => tone({ freq: f, duration: 0.12, type: 'sine', gain: 0.16 }), i * 70));
  }
};

export function resumeOnInterruptionEnd() {
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && ctx && ctx.state === 'suspended') ctx.resume().catch(() => {});
  });
}

// Hard-stops ALL audio output immediately, including tones already scheduled/playing
// (setMuted/setPlatformMuted only gate whether a NEW tone starts). Required for
// "sound doesn't pause when an ad plays or the screen is minimized" - a multi-tone
// sequence like sfx.levelComplete() spans ~270ms via setTimeout, and Web Audio
// oscillators run on their own clock once started, so pausing the game loop alone
// doesn't silence something already in flight the instant a pause/ad event fires.
export function suspendAudio() {
  if (ctx && ctx.state === 'running') ctx.suspend().catch(() => {});
}

export function resumeAudio() {
  if (ctx && ctx.state === 'suspended' && !muted && !platformMuted) ctx.resume().catch(() => {});
}
