// Object-pooled particle system for touch "juice" - avoids per-burst allocation so
// repeated bursts don't trigger GC pauses on mid-range mobile hardware.

const POOL_SIZE = 160;

export function createParticlePool() {
  const pool = Array.from({ length: POOL_SIZE }, () => ({ active: false }));
  let cursor = 0;

  function spawn(x, y, color) {
    const count = 10 + Math.floor(Math.random() * 6);
    for (let i = 0; i < count; i++) {
      const p = pool[cursor];
      cursor = (cursor + 1) % pool.length;
      const angle = Math.random() * Math.PI * 2;
      const speed = 60 + Math.random() * 160;
      p.active = true;
      p.x = x; p.y = y;
      p.vx = Math.cos(angle) * speed;
      p.vy = Math.sin(angle) * speed - 80;
      p.life = 0;
      p.maxLife = 0.5 + Math.random() * 0.4;
      p.size = 3 + Math.random() * 4;
      p.color = color;
    }
  }

  function update(dt) {
    for (const p of pool) {
      if (!p.active) continue;
      p.life += dt;
      if (p.life >= p.maxLife) { p.active = false; continue; }
      p.vy += 340 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
  }

  function draw(ctx) {
    for (const p of pool) {
      if (!p.active) continue;
      const t = p.life / p.maxLife;
      ctx.globalAlpha = 1 - t;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * (1 - t * 0.5), 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  return { spawn, update, draw };
}
