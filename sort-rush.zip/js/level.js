// Sort Rush - level generation, move rules, and a solvability solver.
// Colors are represented as small integers; capacity is fixed per tube.

export const CAPACITY = 4;

export const PALETTE = [
  '#ff5470', '#ffb703', '#4dd0e1', '#7c4dff',
  '#66bb6a', '#ff8a5c', '#ec6ad0', '#5c9dff',
  '#c6ff5c', '#8d6e63'
];

function difficultyForLevel(level) {
  const numColors = Math.min(3 + Math.floor((level - 1) / 2), 9);
  const numEmpty = level <= 3 ? 3 : 2;
  return { numColors, numEmpty };
}

function shuffle(arr, rng) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function dealTubes(numColors, numEmpty, rng) {
  const units = [];
  for (let c = 0; c < numColors; c++) for (let k = 0; k < CAPACITY; k++) units.push(c);
  shuffle(units, rng);
  const tubes = [];
  for (let t = 0; t < numColors; t++) tubes.push(units.slice(t * CAPACITY, t * CAPACITY + CAPACITY));
  for (let e = 0; e < numEmpty; e++) tubes.push([]);
  return tubes;
}

export function isSolved(tubes) {
  return tubes.every(t => t.length === 0 || (t.length === CAPACITY && t.every(c => c === t[0])));
}

function topRun(tube) {
  if (tube.length === 0) return { color: null, count: 0 };
  const color = tube[tube.length - 1];
  let count = 0;
  for (let i = tube.length - 1; i >= 0 && tube[i] === color; i--) count++;
  return { color, count };
}

export function legalMoves(tubes) {
  const moves = [];
  for (let a = 0; a < tubes.length; a++) {
    const { color: colorA, count: countA } = topRun(tubes[a]);
    if (countA === 0) continue;
    for (let b = 0; b < tubes.length; b++) {
      if (a === b) continue;
      const room = CAPACITY - tubes[b].length;
      if (room <= 0) continue;
      const topB = tubes[b].length ? tubes[b][tubes[b].length - 1] : null;
      if (topB !== null && topB !== colorA) continue;
      if (topB === colorA && tubes[b].length === CAPACITY) continue;
      moves.push({ from: a, to: b, color: colorA, count: Math.min(countA, room) });
    }
  }
  return moves;
}

export function applyMove(tubes, from, to) {
  const next = tubes.map(t => t.slice());
  const { color, count } = topRun(next[from]);
  const room = CAPACITY - next[to].length;
  const moved = Math.min(count, room);
  for (let i = 0; i < moved; i++) {
    next[from].pop();
    next[to].push(color);
  }
  return { tubes: next, moved, color };
}

function stateKey(tubes) {
  return tubes.map(t => t.join('')).join('|');
}

// Binary min-heap keyed by numeric priority - backs the A* open set below. A plain
// BFS blows up combinatorially past ~4 colors (branching factor and state count grow
// too fast to explore blindly); A* with a fragmentation heuristic finds a solution by
// searching only the states that plausibly lead toward "solved", not everything reachable.
class MinHeap {
  constructor() { this.items = []; }
  get size() { return this.items.length; }
  push(item, priority) {
    const items = this.items;
    items.push({ item, priority });
    let i = items.length - 1;
    while (i > 0) {
      const parent = (i - 1) >> 1;
      if (items[parent].priority <= items[i].priority) break;
      [items[parent], items[i]] = [items[i], items[parent]];
      i = parent;
    }
  }
  pop() {
    const items = this.items;
    const top = items[0];
    const last = items.pop();
    if (items.length) {
      items[0] = last;
      let i = 0;
      for (;;) {
        const l = i * 2 + 1, r = i * 2 + 2;
        let smallest = i;
        if (l < items.length && items[l].priority < items[smallest].priority) smallest = l;
        if (r < items.length && items[r].priority < items[smallest].priority) smallest = r;
        if (smallest === i) break;
        [items[smallest], items[i]] = [items[i], items[smallest]];
        i = smallest;
      }
    }
    return top.item;
  }
}

// Estimates remaining work as how fragmented each color still is across tubes -
// 0 once every color occupies a single tube, higher the more it's spread out.
function heuristic(tubes) {
  const tubesPerColor = new Map();
  for (const tube of tubes) {
    const seen = new Set(tube);
    for (const color of seen) tubesPerColor.set(color, (tubesPerColor.get(color) || 0) + 1);
  }
  let h = 0;
  for (const count of tubesPerColor.values()) if (count > 1) h += (count - 1) * 2;
  return h;
}

// A* search for a solving path. Bounded so it never hangs the main thread on mobile.
function solve(tubes, { stateCap = 40000, maxDepth = 120 } = {}) {
  if (isSolved(tubes)) return [];
  const startKey = stateKey(tubes);
  const open = new MinHeap();
  open.push({ tubes, path: [] }, heuristic(tubes));
  const bestG = new Map([[startKey, 0]]);
  let explored = 0;

  while (open.size && explored < stateCap) {
    const node = open.pop();
    const g = node.path.length;
    if (g >= maxDepth) continue;

    const moves = legalMoves(node.tubes);
    for (const m of moves) {
      const { tubes: t2 } = applyMove(node.tubes, m.from, m.to);
      const key = stateKey(t2);
      const g2 = g + 1;
      if (bestG.has(key) && bestG.get(key) <= g2) continue;
      bestG.set(key, g2);
      explored++;
      const path = node.path.concat([{ from: m.from, to: m.to }]);
      if (isSolved(t2)) return path;
      open.push({ tubes: t2, path }, g2 + heuristic(t2));
      if (explored >= stateCap) break;
    }
  }
  return null;
}

export function hasAnyLegalMove(tubes) {
  return legalMoves(tubes).length > 0;
}

export function findHint(tubes) {
  const path = solve(tubes, { stateCap: 40000, maxDepth: 120 });
  return path && path.length ? path[0] : null;
}

export function generateLevel(level, rng = Math.random) {
  const { numColors, numEmpty } = difficultyForLevel(level);
  let colors = numColors;

  for (let attempt = 0; attempt < 25; attempt++) {
    const tubes = dealTubes(colors, numEmpty, rng);
    if (isSolved(tubes)) continue;
    const path = solve(tubes, { stateCap: 40000, maxDepth: 120 });
    if (path) {
      return { tubes, colors, numEmpty, level, parMoves: path.length };
    }
    if (attempt > 0 && attempt % 8 === 0 && colors > 2) colors--;
  }
  // Guaranteed-terminating fallback: small, always-quick-to-verify puzzle.
  const tubes = dealTubes(2, 2, rng);
  const path = solve(tubes, { stateCap: 5000, maxDepth: 30 }) || [];
  return { tubes, colors: 2, numEmpty: 2, level, parMoves: path.length || 1 };
}

export function extraEmptyTube(tubes) {
  return tubes.concat([[]]);
}
