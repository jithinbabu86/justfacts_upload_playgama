// Save data via the Playgama Bridge storage module, falling back to localStorage
// when the bridge isn't ready or storage is unavailable (offline, unsupported platform).

function localGet(key) {
  try {
    const raw = localStorage.getItem(key);
    return raw === null ? null : JSON.parse(raw);
  } catch {
    return null;
  }
}

function localSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Storage full or disabled (private browsing) - silently ignore, nothing to save to.
  }
}

export async function loadState(bridge, key, fallback) {
  if (bridge && bridge.isInitialized) {
    try {
      const value = await bridge.storage.get(key);
      if (value !== null && value !== undefined) return value;
    } catch {
      // fall through to local
    }
  }
  const local = localGet(key);
  return local === null ? fallback : local;
}

export async function saveState(bridge, key, value) {
  localSet(key, value);
  if (bridge && bridge.isInitialized) {
    try {
      await bridge.storage.set(key, value);
    } catch {
      // localStorage already has it; nothing else to do.
    }
  }
}
