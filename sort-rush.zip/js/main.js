import {
  generateLevel, applyMove, legalMoves, hasAnyLegalMove, isSolved,
  findHint, extraEmptyTube, PALETTE
} from './level.js';
import { createRenderer } from './render.js';
import { createParticlePool } from './particles.js';
import { sfx, unlockAudio, setMuted, isMuted, setPlatformMuted, resumeOnInterruptionEnd, suspendAudio, resumeAudio } from './audio.js';
import { haptics } from './haptics.js';
import { loadState, saveState } from './storage.js';
import { renderIcon, mountIcons } from './icons.js';
import {
  initSdk, setLoadingProgress, showInterstitial, showRewarded, signalGameReady,
  signalLevelStarted, signalLevelCompleted,
  getLeaderboardType, submitScore, fetchLeaderboardEntries, showNativeLeaderboard,
  authorizePlayer
} from './sdk.js';

const FREE_UNDOS_PER_LEVEL = 3;
const POUR_DURATION = 0.26;
const INTERSTITIAL_COOLDOWN_MS = 180000; // 3 minutes, per platform ad-frequency rules
// Must match a leaderboard configured under this id on the Playgama developer dashboard.
const LEADERBOARD_ID = 'sortrush_highest_level';

const el = (id) => document.getElementById(id);
const screens = {
  loading: el('loading-screen'),
  tutorial: el('tutorial-screen'),
  game: el('game-screen'),
  complete: el('complete-screen'),
  stuck: el('stuck-screen'),
  leaderboard: el('leaderboard-screen')
};

const canvas = el('game-canvas');
const renderer = createRenderer(canvas);
const particles = createParticlePool();

const state = {
  bridge: null,
  level: 1,
  gems: 0,
  streak: 0,
  lastPlayedDate: null,
  tubes: [],
  history: [],
  moves: 0,
  parMoves: 1,
  undosLeft: FREE_UNDOS_PER_LEVEL,
  selected: -1,
  anim: null,
  solvedFlash: [],
  shake: 0,
  paused: false,
  isAnimating: false,
  lastInterstitialAt: 0
};

function showScreen(name) {
  Object.entries(screens).forEach(([key, node]) => node.classList.toggle('hidden', key !== name));
}

function showOverlay(name) {
  screens[name].classList.remove('hidden');
}
function hideOverlay(name) {
  screens[name].classList.add('hidden');
}

// ---------- Persistence ----------
const KEYS = { level: 'sortrush_level', gems: 'sortrush_gems', muted: 'sortrush_muted', seenTutorial: 'sortrush_seen_tutorial', streak: 'sortrush_streak', lastDate: 'sortrush_last_date' };

// Saves gems/streak only - level number is persisted separately (see persistLevel)
// so an ad-reward save on the complete screen can never clobber the next-level pointer.
async function persistProgress() {
  await saveState(state.bridge, KEYS.gems, state.gems);
  await saveState(state.bridge, KEYS.streak, state.streak);
  await saveState(state.bridge, KEYS.lastDate, state.lastPlayedDate);
}

async function persistLevel(levelNumber) {
  await saveState(state.bridge, KEYS.level, levelNumber);
}

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function updateStreakOnLevelComplete() {
  const today = todayIso();
  if (state.lastPlayedDate === today) return;
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  state.streak = state.lastPlayedDate === yesterday ? state.streak + 1 : 1;
  state.lastPlayedDate = today;
}

// ---------- HUD ----------
function refreshHud() {
  el('level-num').textContent = state.level;
  el('gems-count').textContent = state.gems;
  el('undo-count').textContent = state.undosLeft;
  const streakBadge = el('streak-badge');
  if (state.streak > 1) {
    streakBadge.classList.remove('hidden');
    el('streak-count').textContent = state.streak;
  } else {
    streakBadge.classList.add('hidden');
  }
}

// ---------- Level lifecycle ----------
function loadLevel(levelNumber, { resetUndos = true } = {}) {
  const generated = generateLevel(levelNumber);
  state.level = levelNumber;
  state.tubes = generated.tubes;
  state.parMoves = generated.parMoves;
  state.moves = 0;
  state.history = [];
  state.selected = -1;
  state.anim = null;
  state.isAnimating = false;
  state.solvedFlash = generated.tubes.map(() => 0);
  if (resetUndos) state.undosLeft = FREE_UNDOS_PER_LEVEL;
  renderer.resize(state.tubes.length);
  refreshHud();
  signalLevelStarted(state.bridge, levelNumber);
}

function snapshotHistory() {
  state.history.push({ tubes: state.tubes.map(t => t.slice()), moves: state.moves });
}

function tubeIsFreshlySolved(idx) {
  const t = state.tubes[idx];
  return t.length > 0 && isSolved([t]);
}

function tryMove(from, to) {
  if (from === to || state.isAnimating) return false;
  const moves = legalMoves(state.tubes);
  const move = moves.find(m => m.from === from && m.to === to);
  if (!move) return false;

  snapshotHistory();
  const fromCountAtStart = state.tubes[from].length;
  const toCountAtStart = state.tubes[to].length;
  const layout = renderer.getLayout();
  const segH = layout.segH;

  state.isAnimating = true;
  state.anim = {
    from, to, color: move.color, count: move.count,
    fromCountAtStart, toCountAtStart, segH,
    t: 0, elapsed: 0,
    onDone: () => finishMove(from, to)
  };
  state.moves++;
  state.selected = -1;
  sfx.pour();
  haptics.pour();
  return true;
}

function finishMove(from, to) {
  const { tubes } = applyMove(state.tubes, from, to);
  state.tubes = tubes;
  state.anim = null;
  state.isAnimating = false;

  if (tubeIsFreshlySolved(to)) {
    state.solvedFlash[to] = 1;
    sfx.tubeSolved();
    haptics.solved();
    particles.spawn(
      renderer.getLayout().tubes[to].x + renderer.getLayout().tubes[to].w / 2,
      renderer.getLayout().tubes[to].y,
      getTubeColor(to)
    );
  }

  if (isSolved(state.tubes)) {
    onLevelComplete();
  } else if (!hasAnyLegalMove(state.tubes)) {
    showOverlay('stuck');
  }
}

function getTubeColor(idx) {
  const t = state.tubes[idx];
  return t.length ? PALETTE[t[t.length - 1]] : '#fff';
}

function starsForMoves(moves, par) {
  if (moves <= Math.ceil(par * 1.2)) return 3;
  if (moves <= Math.ceil(par * 1.6)) return 2;
  return 1;
}

async function onLevelComplete() {
  updateStreakOnLevelComplete();
  const reward = 8 + state.level;
  state.gems += reward;
  refreshHud();
  await persistProgress();
  await persistLevel(state.level + 1);
  submitScore(state.bridge, LEADERBOARD_ID, state.level + 1); // fire-and-forget, never blocks the UI
  signalLevelCompleted(state.bridge, state.level);

  const stars = starsForMoves(state.moves, state.parMoves);
  el('complete-stars').textContent = '★★★'.slice(0, stars).padEnd(3, '☆').split('').join(' ');
  el('complete-sub').textContent = `Level ${state.level} complete — +${reward} 💎`;
  el('double-reward-amount').textContent = reward;
  el('double-reward-btn').dataset.consumed = '0';
  showOverlay('complete');
  sfx.levelComplete();
  haptics.levelComplete();
}

async function goToNextLevel() {
  hideOverlay('complete');
  const now = Date.now();
  if (now - state.lastInterstitialAt > INTERSTITIAL_COOLDOWN_MS) {
    state.lastInterstitialAt = now;
    await showInterstitial(state.bridge, 'between_levels');
  }
  loadLevel(state.level + 1);
}

function restartLevel() {
  hideOverlay('stuck');
  loadLevel(state.level, { resetUndos: true });
}

// ---------- Undo / Hint / Extra tube ----------
async function onUndo() {
  if (state.isAnimating || state.history.length === 0) return;
  if (state.undosLeft > 0) {
    doUndo();
    state.undosLeft--;
    refreshHud();
    return;
  }
  const rewarded = await showRewarded(state.bridge, 'undo');
  if (rewarded) {
    doUndo();
    refreshHud();
  }
}

function doUndo() {
  const prev = state.history.pop();
  state.tubes = prev.tubes;
  state.moves = prev.moves;
  state.selected = -1;
  sfx.button();
  haptics.tap();
}

let hintPulse = null;
async function onHint() {
  if (state.isAnimating) return;
  const rewarded = await showRewarded(state.bridge, 'hint');
  if (!rewarded) return;
  const move = findHint(state.tubes);
  if (!move) {
    showOverlay('stuck');
    return;
  }
  state.selected = move.from;
  hintPulse = { to: move.to, until: performance.now() + 1500 };
  sfx.reward();
}

async function onExtraTube() {
  if (state.isAnimating) return;
  const rewarded = await showRewarded(state.bridge, 'extra_tube');
  if (!rewarded) return;
  state.tubes = extraEmptyTube(state.tubes);
  state.solvedFlash.push(0);
  renderer.resize(state.tubes.length);
  sfx.reward();
}

async function onDoubleReward() {
  const btn = el('double-reward-btn');
  if (btn.dataset.consumed === '1') return;
  const rewarded = await showRewarded(state.bridge, 'double_reward');
  if (rewarded) {
    const bonus = Number(el('double-reward-amount').textContent);
    state.gems += bonus;
    refreshHud();
    await persistProgress();
    btn.dataset.consumed = '1';
    btn.querySelector('#double-reward-label').textContent = 'Claimed!';
    sfx.reward();
  }
}

// ---------- Input ----------
function handlePointer(clientX, clientY) {
  if (state.isAnimating) return;
  unlockAudio();
  const idx = renderer.hitTest(clientX, clientY);
  if (idx === -1) return;

  if (state.selected === -1) {
    if (state.tubes[idx].length > 0) {
      state.selected = idx;
      sfx.select();
      haptics.tap();
    }
    return;
  }

  if (state.selected === idx) {
    state.selected = -1;
    return;
  }

  const moved = tryMove(state.selected, idx);
  if (!moved) {
    sfx.invalid();
    haptics.invalid();
    state.shake = 6;
    state.selected = state.tubes[idx].length > 0 ? idx : -1;
  }
}

canvas.addEventListener('pointerdown', (e) => {
  e.preventDefault();
  handlePointer(e.clientX, e.clientY);
}, { passive: false });

// ---------- Game loop ----------
function update(dt) {
  particles.update(dt);
  if (state.shake > 0) state.shake = Math.max(0, state.shake - dt * 40);
  for (let i = 0; i < state.solvedFlash.length; i++) {
    if (state.solvedFlash[i] > 0) state.solvedFlash[i] = Math.max(0, state.solvedFlash[i] - dt * 1.2);
  }

  if (state.anim) {
    state.anim.elapsed += dt;
    state.anim.t = Math.min(state.anim.elapsed / POUR_DURATION, 1);
    if (state.anim.t >= 1) {
      const done = state.anim.onDone;
      done();
    }
  }

  if (hintPulse && performance.now() > hintPulse.until) hintPulse = null;
}

function render(time) {
  const flash = state.solvedFlash.slice();
  if (hintPulse) flash[hintPulse.to] = Math.max(flash[hintPulse.to] || 0, 0.6);
  renderer.draw({
    tubes: state.tubes,
    selected: state.selected,
    particles,
    anim: state.anim,
    shake: state.shake,
    solvedFlash: flash,
    time
  });
}

let lastTime = 0;
function loop(now) {
  requestAnimationFrame(loop);
  if (!lastTime) lastTime = now;
  const dt = Math.min((now - lastTime) / 1000, 0.05);
  lastTime = now;
  if (state.paused) return;
  update(dt);
  render(now / 1000);
}

// ---------- Pause / resume ----------
function pauseGame() { state.paused = true; suspendAudio(); }
function resumeGame() { state.paused = false; lastTime = 0; resumeAudio(); }

document.addEventListener('visibilitychange', () => {
  if (document.hidden) pauseGame(); else resumeGame();
});
window.addEventListener('blur', pauseGame);
window.addEventListener('focus', resumeGame);
window.addEventListener('resize', () => renderer.resize(state.tubes.length));
window.addEventListener('orientationchange', () => renderer.resize(state.tubes.length));
document.addEventListener('touchstart', unlockAudio, { once: true, passive: true });

// ---------- Tutorial ----------
const TUTORIAL_SLIDES = [
  { icon: 'flask', text: 'Tap a tube to pick it up, then tap another to pour matching colors in.' },
  { icon: 'target', text: 'Sort every tube into a single solid color to clear the level.' },
  { icon: 'hint', text: 'Stuck? Undo a move or watch a quick ad for a hint or an extra tube.' }
];
let tutorialIndex = 0;

function renderTutorialSlide() {
  const slide = TUTORIAL_SLIDES[tutorialIndex];
  el('tutorial-art').innerHTML = `<span class="tutorial-icon">${renderIcon(slide.icon)}</span><span class="tap-hint"></span>`;
  el('tutorial-text').textContent = slide.text;
  document.querySelectorAll('.dot').forEach((d, i) => d.classList.toggle('active', i === tutorialIndex));
  el('tutorial-next').textContent = tutorialIndex === TUTORIAL_SLIDES.length - 1 ? 'Play!' : 'Next';
}

el('tutorial-next').addEventListener('click', async () => {
  sfx.button();
  if (tutorialIndex < TUTORIAL_SLIDES.length - 1) {
    tutorialIndex++;
    renderTutorialSlide();
  } else {
    await saveState(state.bridge, KEYS.seenTutorial, true);
    startGame();
  }
});

// ---------- Leaderboard ----------
// Names/photos come from other players via the platform - never trusted as HTML, so this
// builds DOM nodes with textContent/src assignment rather than interpolating into innerHTML.
function renderLeaderboardEntries(entries) {
  const list = el('leaderboard-list');
  list.innerHTML = '';
  if (!entries.length) {
    const empty = document.createElement('div');
    empty.className = 'leaderboard-empty';
    empty.textContent = 'No scores yet — be the first!';
    list.appendChild(empty);
    return;
  }
  const myId = state.bridge?.player?.id ?? null;
  for (const entry of entries) {
    const row = document.createElement('div');
    row.className = 'leaderboard-row' + (myId !== null && entry.id === myId ? ' is-me' : '');

    const rank = document.createElement('span');
    rank.className = 'leaderboard-rank';
    rank.textContent = entry.rank;

    let avatar;
    if (entry.photo) {
      avatar = document.createElement('img');
      avatar.className = 'leaderboard-avatar';
      avatar.src = entry.photo;
      avatar.alt = '';
    } else {
      avatar = document.createElement('span');
      avatar.className = 'leaderboard-avatar';
      avatar.textContent = (entry.name || '?').trim().charAt(0).toUpperCase();
    }

    const name = document.createElement('span');
    name.className = 'leaderboard-name';
    name.textContent = entry.name || 'Player';

    const score = document.createElement('span');
    score.className = 'leaderboard-score';
    score.textContent = `Lv ${entry.score}`;

    row.append(rank, avatar, name, score);
    list.appendChild(row);
  }
}

async function onOpenLeaderboard() {
  sfx.button();
  // Leaderboard is our one account-based feature - per wiki.playgama.com/playgama/bridge-sdk/api/player,
  // authorize() must be triggered by a direct player action (this tap), not silently at boot.
  // Best-effort: proceed to show the leaderboard regardless of whether they authorize or decline.
  await authorizePlayer(state.bridge);
  const type = getLeaderboardType(state.bridge);
  if (type === 'native' || type === 'native_popup') {
    const opened = await showNativeLeaderboard(state.bridge, LEADERBOARD_ID);
    if (opened) return;
    // Fall through to the in-game list if the native popup failed to open.
  }
  const entries = await fetchLeaderboardEntries(state.bridge, LEADERBOARD_ID);
  renderLeaderboardEntries(entries);
  showOverlay('leaderboard');
}

// Disables a button for the duration of an async handler - defense-in-depth against a
// fast double-tap firing the handler twice before the first call's ad promise resolves.
// js/sdk.js already de-dupes concurrent showRewarded/showInterstitial calls at the source,
// but this stops the second tap from even reaching the handler in the first place.
function withButtonLock(button, handler) {
  return async (...args) => {
    if (button.disabled) return;
    button.disabled = true;
    try {
      await handler(...args);
    } finally {
      button.disabled = false;
    }
  };
}

function setMuteIcon(muted) {
  el('mute-btn').querySelector('.btn-icon').innerHTML = renderIcon(muted ? 'speakerOff' : 'speakerOn');
}

// ---------- Wiring ----------
el('mute-btn').addEventListener('click', () => {
  const next = !isMuted();
  setMuted(next);
  setMuteIcon(next);
  saveState(state.bridge, KEYS.muted, next);
});
el('restart-btn').addEventListener('click', () => { sfx.button(); loadLevel(state.level); });
el('undo-btn').addEventListener('click', withButtonLock(el('undo-btn'), onUndo));
el('hint-btn').addEventListener('click', withButtonLock(el('hint-btn'), onHint));
el('extra-slot-btn').addEventListener('click', withButtonLock(el('extra-slot-btn'), onExtraTube));
el('next-level-btn').addEventListener('click', withButtonLock(el('next-level-btn'), goToNextLevel));
el('double-reward-btn').addEventListener('click', withButtonLock(el('double-reward-btn'), onDoubleReward));
el('stuck-hint-btn').addEventListener('click', withButtonLock(el('stuck-hint-btn'), async () => { hideOverlay('stuck'); await onHint(); }));
el('stuck-restart-btn').addEventListener('click', restartLevel);
el('leaderboard-btn').addEventListener('click', withButtonLock(el('leaderboard-btn'), onOpenLeaderboard));
el('leaderboard-close-btn').addEventListener('click', () => hideOverlay('leaderboard'));

function startGame() {
  showScreen('game');
  loadLevel(state.level);
}

mountIcons();

async function boot() {
  el('progress-fill').style.width = '10%';

  state.bridge = await initSdk({
    onPause: pauseGame,
    onResume: resumeGame,
    onAudioEnabledChange: (enabled) => setPlatformMuted(!enabled)
  });
  setLoadingProgress(state.bridge, 40);
  el('progress-fill').style.width = '55%';
  resumeOnInterruptionEnd();

  state.level = await loadState(state.bridge, KEYS.level, 1);
  state.gems = await loadState(state.bridge, KEYS.gems, 0);
  state.streak = await loadState(state.bridge, KEYS.streak, 0);
  state.lastPlayedDate = await loadState(state.bridge, KEYS.lastDate, null);
  const muted = await loadState(state.bridge, KEYS.muted, true);
  setMuted(muted);
  setMuteIcon(muted);

  if (getLeaderboardType(state.bridge) !== 'not_available') {
    el('leaderboard-btn').classList.remove('hidden');
  }

  setLoadingProgress(state.bridge, 90);
  el('progress-fill').style.width = '90%';

  const seenTutorial = await loadState(state.bridge, KEYS.seenTutorial, false);
  setLoadingProgress(state.bridge, 100);
  el('progress-fill').style.width = '100%';

  requestAnimationFrame(loop);

  // Everything above is loaded and the player is about to see either the tutorial or
  // gameplay - this is the actual "ready" point the platform's own review gate waits on.
  await signalGameReady(state.bridge);

  if (seenTutorial) {
    startGame();
  } else {
    showScreen('tutorial');
    renderTutorialSlide();
  }
}

// Guard against an unhandled promise rejection if anything in boot() throws (e.g. a
// synchronous throw from bridge.on() during initSdk) - without this, a failure here
// silently kills the boot sequence with no error surfaced anywhere.
boot().catch((err) => {
  console.error('Sort Rush failed to start:', err);
});
