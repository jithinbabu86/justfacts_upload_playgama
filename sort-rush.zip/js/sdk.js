// Wrapper around the real Playgama Bridge SDK (@playgama/bridge, loaded via CDN script tag
// in index.html). Verified against the SDK source (github.com/playgama/bridge) rather than
// guessed - method names, module shape, and event string literals below match the actual source.

// Event name / state string literals (src/constants/eventName.ts, .../advertisement/constants.ts)
const EVENT = {
  PAUSE_STATE_CHANGED: 'pause_state_changed',
  AUDIO_STATE_CHANGED: 'audio_state_changed',
  ORIENTATION_STATE_CHANGED: 'orientation_state_changed',
  REWARDED_STATE_CHANGED: 'rewarded_state_changed',
  INTERSTITIAL_STATE_CHANGED: 'interstitial_state_changed'
};

// Platform message string literals (src/modules/platform/constants.ts). 'game_ready' is
// distinct from setGameLoadingProgress() - it's the actual readiness signal the platform's
// own submission review waits on; without it the platform times out waiting for the game.
// level_started/level_completed are optional per wiki.playgama.com but recommended for the
// platform's own analytics - skipping gameplay_started/stopped and level_failed since this
// game has no clean moment to map them to (no fail state, no distinct "left the game" event).
const PLATFORM_MESSAGE = {
  GAME_READY: 'game_ready',
  LEVEL_STARTED: 'level_started',
  LEVEL_COMPLETED: 'level_completed'
};

// The UMD build's webpack wrapper (library.name: 'bridge') reassigns the top-level
// window.bridge to the module's *exports namespace* (constants + a nested .bridge/.default),
// clobbering the actual singleton instance that the module's own code assigns during setup.
// window.playgamaBridge is left untouched and IS the real instance - confirmed by loading
// the live CDN script and inspecting both globals. window.bridge.bridge/.default are kept as
// fallbacks in case a future SDK version changes this, but playgamaBridge is checked first.
function getRealBridge() {
  const candidates = [window.playgamaBridge, window.bridge, window.bridge?.bridge, window.bridge?.default];
  for (const b of candidates) {
    if (b && typeof b.initialize === 'function') return b;
  }
  return null;
}

// Minimal no-op stand-in so the game runs standalone outside the Playgama platform
// (local testing, or the CDN failing to load on a flaky mobile network).
function createMockBridge() {
  const listeners = {};
  return {
    isInitialized: true,
    isMock: true,
    async initialize() {},
    setGameLoadingProgress() {},
    storage: {
      async get() { return null; },
      async set() {},
      async delete() {}
    },
    advertisement: {
      isInterstitialSupported: false,
      isRewardedSupported: false,
      preloadInterstitial() {},
      preloadRewarded() {},
      showInterstitial() {
        setTimeout(() => listeners[EVENT.INTERSTITIAL_STATE_CHANGED]?.forEach(fn => fn({ state: 'closed' })), 0);
      },
      showRewarded() {
        setTimeout(() => {
          listeners[EVENT.REWARDED_STATE_CHANGED]?.forEach(fn => fn({ state: 'rewarded' }));
          listeners[EVENT.REWARDED_STATE_CHANGED]?.forEach(fn => fn({ state: 'closed' }));
        }, 0);
      },
      setMinimumDelayBetweenInterstitial() {}
    },
    // No real platform to rank against outside Playgama, so leaderboards report
    // unavailable here - the UI hides the leaderboard button entirely in that case.
    leaderboards: {
      type: 'not_available',
      async setScore() {},
      async getEntries() { return []; },
      async showNativePopup() {}
    },
    platform: {
      isPaused: false,
      isAudioEnabled: true,
      async sendMessage() {},
      on(event, fn) { (listeners[event] = listeners[event] || []).push(fn); },
      off(event, fn) {
        if (!listeners[event]) return;
        listeners[event] = listeners[event].filter(f => f !== fn);
      }
    },
    on(event, fn) { (listeners[event] = listeners[event] || []).push(fn); },
    off(event, fn) {
      if (!listeners[event]) return;
      listeners[event] = listeners[event].filter(f => f !== fn);
    }
  };
}

export async function initSdk({ onPause, onResume, onAudioEnabledChange } = {}) {
  const bridge = getRealBridge() || createMockBridge();

  try {
    await bridge.initialize();
  } catch {
    // Initialization failed (e.g. unsupported platform) - keep going with whatever the
    // bridge can offer; ad calls below are already guarded by isSupported checks.
  }

  // Per wiki.playgama.com/playgama/bridge-sdk/api/platform: subscribe via
  // bridge.platform.on(...) specifically (not the top-level bridge.on), and the payload
  // is a plain boolean, not an event object. Critically, the docs call out that these
  // events only fire on SUBSEQUENT changes - a game that starts already paused/muted
  // would never see a "change" and would incorrectly keep running/making sound unless
  // the current value is also read once, up front, via the isPaused/isAudioEnabled
  // getters. That initial-state check (not just the subscription itself) is almost
  // certainly why "platform pause/mute signal ignored" was reported.
  if (bridge.platform && typeof bridge.platform.on === 'function') {
    bridge.platform.on(EVENT.PAUSE_STATE_CHANGED, (isPaused) => {
      if (isPaused) onPause?.(); else onResume?.();
    });
    if (bridge.platform.isPaused) onPause?.();

    bridge.platform.on(EVENT.AUDIO_STATE_CHANGED, (isEnabled) => {
      onAudioEnabledChange?.(isEnabled);
    });
    onAudioEnabledChange?.(bridge.platform.isAudioEnabled !== false);
  }

  try {
    bridge.advertisement.setMinimumDelayBetweenInterstitial?.(60);
    bridge.advertisement.preloadInterstitial?.();
    bridge.advertisement.preloadRewarded?.();
  } catch {
    // Ads unsupported on this platform - rewarded/interstitial calls below no-op safely.
  }

  return bridge;
}

export function setLoadingProgress(bridge, percent) {
  try { bridge.setGameLoadingProgress?.(percent); } catch { /* non-fatal */ }
}

// Call once, right before showing the tutorial/game screen (i.e. once the player can
// actually interact with something) - the platform's own review/session gate waits on
// this and times out without it. The SDK's own sendMessage('game_ready') handler is
// documented as duplicate-call-safe, but a local guard avoids the (harmless) extra call.
let gameReadySent = false;
export async function signalGameReady(bridge) {
  if (gameReadySent) return;
  gameReadySent = true;
  try {
    await bridge.platform.sendMessage(PLATFORM_MESSAGE.GAME_READY);
  } catch {
    // Non-fatal locally, but this is the one signal the platform actually gates on -
    // if this keeps failing in production it needs investigation, not silent swallowing.
    console.error('Sort Rush: failed to send game_ready platform message');
  }
}

// Optional analytics signals (recommended, not required) - best-effort, never surfaced
// to the player if they fail.
export function signalLevelStarted(bridge, level) {
  try { bridge.platform?.sendMessage(PLATFORM_MESSAGE.LEVEL_STARTED, { level }); } catch { /* non-fatal */ }
}

export function signalLevelCompleted(bridge, level) {
  try { bridge.platform?.sendMessage(PLATFORM_MESSAGE.LEVEL_COMPLETED, { level }); } catch { /* non-fatal */ }
}

// Only one interstitial/rewarded ad can ever actually be playing at once, so a second
// call while one is in flight must never register its own listener - two listeners on
// the same broadcast event would both resolve `true` off a single ad view, double-granting
// whatever reward that call promised (e.g. a fast double-tap on "Watch Ad" crediting gems
// twice). Concurrent callers instead get the SAME promise as the call already in flight.
let pendingInterstitial = null;
let pendingRewarded = null;

export async function showInterstitial(bridge, placement) {
  if (pendingInterstitial) return pendingInterstitial;
  if (!bridge?.advertisement?.isInterstitialSupported) return false;

  pendingInterstitial = new Promise((resolve) => {
    const handler = (payload) => {
      const state = payload?.state ?? payload;
      if (state === 'closed' || state === 'failed') {
        bridge.off?.(EVENT.INTERSTITIAL_STATE_CHANGED, handler);
        resolve(state === 'closed');
      }
    };
    bridge.on?.(EVENT.INTERSTITIAL_STATE_CHANGED, handler);
    try {
      bridge.advertisement.showInterstitial(placement);
    } catch {
      bridge.off?.(EVENT.INTERSTITIAL_STATE_CHANGED, handler);
      resolve(false);
    }
  }).finally(() => {
    pendingInterstitial = null;
    preloadAds(bridge);
  });

  return pendingInterstitial;
}

// Resolves true only if the player watched through to the reward, never rejects -
// a failed/skipped ad should degrade gracefully, not punish the player.
export async function showRewarded(bridge, placement) {
  if (pendingRewarded) return pendingRewarded;
  if (!bridge?.advertisement?.isRewardedSupported) return false;

  pendingRewarded = new Promise((resolve) => {
    let rewarded = false;
    const handler = (payload) => {
      const state = payload?.state ?? payload;
      if (state === 'rewarded') rewarded = true;
      if (state === 'closed' || state === 'failed') {
        bridge.off?.(EVENT.REWARDED_STATE_CHANGED, handler);
        resolve(rewarded);
      }
    };
    bridge.on?.(EVENT.REWARDED_STATE_CHANGED, handler);
    try {
      bridge.advertisement.showRewarded(placement);
    } catch {
      bridge.off?.(EVENT.REWARDED_STATE_CHANGED, handler);
      resolve(false);
    }
  }).finally(() => {
    pendingRewarded = null;
    preloadAds(bridge);
  });

  return pendingRewarded;
}

export function preloadAds(bridge) {
  try {
    bridge.advertisement.preloadInterstitial?.();
    bridge.advertisement.preloadRewarded?.();
  } catch { /* unsupported platform */ }
}

// ---------- Leaderboards (src/modules/leaderboards/LeaderboardsModule.ts) ----------
// type is one of 'not_available' | 'in_game' | 'native' | 'native_popup' - varies per
// platform the game is embedded on, so callers must branch on it rather than assume support.
export function getLeaderboardType(bridge) {
  return bridge?.leaderboards?.type || 'not_available';
}

export async function submitScore(bridge, id, score) {
  if (getLeaderboardType(bridge) === 'not_available') return;
  try {
    await bridge.leaderboards.setScore(id, score);
  } catch {
    // Non-fatal - the player's progress is already saved locally regardless.
  }
}

export async function fetchLeaderboardEntries(bridge, id) {
  try {
    return await bridge.leaderboards.getEntries(id);
  } catch {
    return [];
  }
}

export async function showNativeLeaderboard(bridge, id) {
  try {
    await bridge.leaderboards.showNativePopup(id);
    return true;
  } catch {
    return false;
  }
}
