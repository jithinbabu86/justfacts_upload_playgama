// Wrapper around the real Playgama Bridge SDK (@playgama/bridge, loaded via CDN script tag
// in index.html). Verified against the SDK source (github.com/playgama/bridge) rather than
// guessed - method names, module shape, and event string literals below match the actual source.

// Event name / state string literals (src/constants/eventName.ts, .../advertisement/constants.ts)
const EVENT = {
  PAUSE_STATE_CHANGED: 'pause_state_changed',
  AUDIO_STATE_CHANGED: 'audio_state_changed',
  ORIENTATION_STATE_CHANGED: 'orientation_state_changed',
  REWARDED_STATE_CHANGED: 'rewarded_state_changed',
  INTERSTITIAL_STATE_CHANGED: 'interstitial_state_changed'
};

// Platform message string literal (src/modules/platform/constants.ts). 'game_ready' is
// distinct from setGameLoadingProgress() - it's the actual readiness signal the platform's
// own submission review waits on; without it the platform times out waiting for the game.
// (The same constants file also defines level_started/level_completed/gameplay_started etc.
// for finer-grained analytics - not wired up here since this game has no clean "gameplay
// stopped"/"level failed" moment to map them to; add them if the platform asks for more.)
const PLATFORM_MESSAGE_GAME_READY = 'game_ready';

// The UMD build's webpack wrapper (library.name: 'bridge') reassigns the top-level
// window.bridge to the module's *exports namespace* (constants + a nested .bridge/.default),
// clobbering the actual singleton instance that the module's own code assigns during setup.
// window.playgamaBridge is left untouched and IS the real instance - confirmed by loading
// the live CDN script and inspecting both globals. window.bridge.bridge/.default are kept as
// fallbacks in case a future SDK version changes this, but playgamaBridge is checked first.
function getRealBridge() {
  const candidates = [window.playgamaBridge, window.bridge, window.bridge?.bridge, window.bridge?.default];
  for (const b of candidates) {
    if (b && typeof b.initialize === 'function') return b;
  }
  return null;
}

// Minimal no-op stand-in so the game runs standalone outside the Playgama platform
// (local testing, or the CDN failing to load on a flaky mobile network).
function createMockBridge() {
  const listeners = {};
  return {
    isInitialized: true,
    isMock: true,
    async initialize() {},
    setGameLoadingProgress() {},
    storage: {
      async get() { return null; },
      async set() {},
      async delete() {}
    },
    advertisement: {
      isInterstitialSupported: false,
      isRewardedSupported: false,
      preloadInterstitial() {},
      preloadRewarded() {},
      showInterstitial() {
        setTimeout(() => listeners[EVENT.INTERSTITIAL_STATE_CHANGED]?.forEach(fn => fn({ state: 'closed' })), 0);
      },
      showRewarded() {
        setTimeout(() => {
          listeners[EVENT.REWARDED_STATE_CHANGED]?.forEach(fn => fn({ state: 'rewarded' }));
          listeners[EVENT.REWARDED_STATE_CHANGED]?.forEach(fn => fn({ state: 'closed' }));
        }, 0);
      },
      setMinimumDelayBetweenInterstitial() {}
    },
    // No real platform to rank against outside Playgama, so leaderboards report
    // unavailable here - the UI hides the leaderboard button entirely in that case.
    leaderboards: {
      type: 'not_available',
      async setScore() {},
      async getEntries() { return []; },
      async showNativePopup() {}
    },
    platform: { async sendMessage() {} },
    on(event, fn) { (listeners[event] = listeners[event] || []).push(fn); },
    off(event, fn) {
      if (!listeners[event]) return;
      listeners[event] = listeners[event].filter(f => f !== fn);
    }
  };
}

export async function initSdk({ onPause, onResume } = {}) {
  const bridge = getRealBridge() || createMockBridge();

  try {
    await bridge.initialize();
  } catch {
    // Initialization failed (e.g. unsupported platform) - keep going with whatever the
    // bridge can offer; ad calls below are already guarded by isSupported checks.
  }

  if (typeof bridge.on === 'function') {
    bridge.on(EVENT.PAUSE_STATE_CHANGED, (payload) => {
      const paused = payload && (payload.state === true || payload.paused === true || payload === true);
      if (paused) onPause?.(); else onResume?.();
    });
  }

  try {
    bridge.advertisement.setMinimumDelayBetweenInterstitial?.(60);
    bridge.advertisement.preloadInterstitial?.();
    bridge.advertisement.preloadRewarded?.();
  } catch {
    // Ads unsupported on this platform - rewarded/interstitial calls below no-op safely.
  }

  return bridge;
}

export function setLoadingProgress(bridge, percent) {
  try { bridge.setGameLoadingProgress?.(percent); } catch { /* non-fatal */ }
}

// Call once, right before showing the tutorial/game screen (i.e. once the player can
// actually interact with something) - the platform's own review/session gate waits on
// this and times out without it. The SDK's own sendMessage('game_ready') handler is
// documented as duplicate-call-safe, but a local guard avoids the (harmless) extra call.
let gameReadySent = false;
export async function signalGameReady(bridge) {
  if (gameReadySent) return;
  gameReadySent = true;
  try {
    await bridge.platform.sendMessage(PLATFORM_MESSAGE_GAME_READY);
  } catch {
    // Non-fatal locally, but this is the one signal the platform actually gates on -
    // if this keeps failing in production it needs investigation, not silent swallowing.
    console.error('Sort Rush: failed to send game_ready platform message');
  }
}

// Only one interstitial/rewarded ad can ever actually be playing at once, so a second
// call while one is in flight must never register its own listener - two listeners on
// the same broadcast event would both resolve `true` off a single ad view, double-granting
// whatever reward that call promised (e.g. a fast double-tap on "Watch Ad" crediting gems
// twice). Concurrent callers instead get the SAME promise as the call already in flight.
let pendingInterstitial = null;
let pendingRewarded = null;

export async function showInterstitial(bridge, placement) {
  if (pendingInterstitial) return pendingInterstitial;
  if (!bridge?.advertisement?.isInterstitialSupported) return false;

  pendingInterstitial = new Promise((resolve) => {
    const handler = (payload) => {
      const state = payload?.state ?? payload;
      if (state === 'closed' || state === 'failed') {
        bridge.off?.(EVENT.INTERSTITIAL_STATE_CHANGED, handler);
        resolve(state === 'closed');
      }
    };
    bridge.on?.(EVENT.INTERSTITIAL_STATE_CHANGED, handler);
    try {
      bridge.advertisement.showInterstitial(placement);
    } catch {
      bridge.off?.(EVENT.INTERSTITIAL_STATE_CHANGED, handler);
      resolve(false);
    }
  }).finally(() => {
    pendingInterstitial = null;
    preloadAds(bridge);
  });

  return pendingInterstitial;
}

// Resolves true only if the player watched through to the reward, never rejects -
// a failed/skipped ad should degrade gracefully, not punish the player.
export async function showRewarded(bridge, placement) {
  if (pendingRewarded) return pendingRewarded;
  if (!bridge?.advertisement?.isRewardedSupported) return false;

  pendingRewarded = new Promise((resolve) => {
    let rewarded = false;
    const handler = (payload) => {
      const state = payload?.state ?? payload;
      if (state === 'rewarded') rewarded = true;
      if (state === 'closed' || state === 'failed') {
        bridge.off?.(EVENT.REWARDED_STATE_CHANGED, handler);
        resolve(rewarded);
      }
    };
    bridge.on?.(EVENT.REWARDED_STATE_CHANGED, handler);
    try {
      bridge.advertisement.showRewarded(placement);
    } catch {
      bridge.off?.(EVENT.REWARDED_STATE_CHANGED, handler);
      resolve(false);
    }
  }).finally(() => {
    pendingRewarded = null;
    preloadAds(bridge);
  });

  return pendingRewarded;
}

export function preloadAds(bridge) {
  try {
    bridge.advertisement.preloadInterstitial?.();
    bridge.advertisement.preloadRewarded?.();
  } catch { /* unsupported platform */ }
}

// ---------- Leaderboards (src/modules/leaderboards/LeaderboardsModule.ts) ----------
// type is one of 'not_available' | 'in_game' | 'native' | 'native_popup' - varies per
// platform the game is embedded on, so callers must branch on it rather than assume support.
export function getLeaderboardType(bridge) {
  return bridge?.leaderboards?.type || 'not_available';
}

export async function submitScore(bridge, id, score) {
  if (getLeaderboardType(bridge) === 'not_available') return;
  try {
    await bridge.leaderboards.setScore(id, score);
  } catch {
    // Non-fatal - the player's progress is already saved locally regardless.
  }
}

export async function fetchLeaderboardEntries(bridge, id) {
  try {
    return await bridge.leaderboards.getEntries(id);
  } catch {
    return [];
  }
}

export async function showNativeLeaderboard(bridge, id) {
  try {
    await bridge.leaderboards.showNativePopup(id);
    return true;
  } catch {
    return false;
  }
}
