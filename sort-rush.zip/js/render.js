import { CAPACITY, PALETTE } from './level.js';

const TUBE_GAP = 14;
const ROW_GAP = 22;
const SIDE_PADDING = 18;

function roundedTubePath(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x + w, y);
  ctx.lineTo(x + w, y + h - r);
  ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
  ctx.lineTo(x + r, y + h);
  ctx.arcTo(x, y + h, x, y + h - r, r);
  ctx.closePath();
}

// Manual rounded-rect path - ctx.roundRect() isn't available on iOS Safari < 16,
// which the mobile support matrix still targets (iOS 15+).
function roundedRectPath(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.arcTo(x + w, y, x + w, y + r, r);
  ctx.lineTo(x + w, y + h - r);
  ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
  ctx.lineTo(x + r, y + h);
  ctx.arcTo(x, y + h, x, y + h - r, r);
  ctx.lineTo(x, y + r);
  ctx.arcTo(x, y, x + r, y, r);
  ctx.closePath();
}

function computeLayout(width, height, numTubes) {
  const rows = numTubes <= 6 ? 1 : numTubes <= 12 ? 2 : 3;
  const cols = Math.ceil(numTubes / rows);

  const availW = width - SIDE_PADDING * 2;
  const tubeW = Math.min((availW - TUBE_GAP * (cols - 1)) / cols, 68);
  const availHPerRow = (height - 24) / rows - ROW_GAP;
  const segH = Math.min(availHPerRow / (CAPACITY + 0.8), tubeW * 1.15, 64);
  const tubeH = segH * CAPACITY + segH * 0.5;

  const rowsContent = rows * tubeH + (rows - 1) * ROW_GAP;
  const startY = Math.max((height - rowsContent) / 2, 16);
  const gridW = cols * tubeW + (cols - 1) * TUBE_GAP;
  const startX = (width - gridW) / 2;

  const tubes = [];
  for (let i = 0; i < numTubes; i++) {
    const row = Math.floor(i / cols);
    const rowStart = row * cols;
    const itemsInRow = Math.min(cols, numTubes - rowStart);
    const rowGridW = itemsInRow * tubeW + (itemsInRow - 1) * TUBE_GAP;
    const rowStartX = (width - rowGridW) / 2;
    const col = i - rowStart;
    tubes.push({
      x: rowStartX + col * (tubeW + TUBE_GAP),
      y: startY + row * (tubeH + ROW_GAP),
      w: tubeW,
      h: tubeH,
      segH
    });
  }
  return { tubes, segH, startX, startY };
}

export function createRenderer(canvas) {
  const ctx = canvas.getContext('2d');
  let dpr = Math.min(window.devicePixelRatio || 1, 2);
  let layout = { tubes: [], segH: 0 };
  let cssW = 0, cssH = 0;

  function resize(numTubes) {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    cssW = canvas.clientWidth;
    cssH = canvas.clientHeight;
    canvas.width = Math.round(cssW * dpr);
    canvas.height = Math.round(cssH * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    layout = computeLayout(cssW, cssH, numTubes);
  }

  function hitTest(clientX, clientY) {
    const rect = canvas.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    for (let i = 0; i < layout.tubes.length; i++) {
      const t = layout.tubes[i];
      const pad = 10;
      if (x >= t.x - pad && x <= t.x + t.w + pad && y >= t.y - pad && y <= t.y + t.h + pad) return i;
    }
    return -1;
  }

  function drawTube(t, colors, { selected, dimTopCount = 0, shakeX = 0, shakeY = 0, solvedGlow = 0 }) {
    const x = t.x + shakeX, y = t.y + shakeY;
    ctx.save();
    if (selected) {
      ctx.shadowColor = 'rgba(124,77,255,0.9)';
      ctx.shadowBlur = 16;
    }
    roundedTubePath(ctx, x, y, t.w, t.h, t.w * 0.28);
    ctx.fillStyle = 'rgba(255,255,255,0.06)';
    ctx.fill();
    ctx.lineWidth = selected ? 3 : 2;
    ctx.strokeStyle = selected ? '#7c4dff' : 'rgba(255,255,255,0.22)';
    ctx.stroke();
    ctx.restore();

    ctx.save();
    roundedTubePath(ctx, x, y, t.w, t.h, t.w * 0.28);
    ctx.clip();
    const visibleCount = Math.max(colors.length - dimTopCount, 0);
    for (let i = 0; i < visibleCount; i++) {
      const color = colors[i];
      const segY = y + t.h - (i + 1) * t.segH;
      ctx.fillStyle = PALETTE[color];
      ctx.fillRect(x, segY, t.w, t.segH + 1);
      ctx.fillStyle = 'rgba(255,255,255,0.14)';
      ctx.fillRect(x, segY, t.w, Math.max(t.segH * 0.22, 3));
    }
    if (solvedGlow > 0) {
      ctx.fillStyle = `rgba(255,255,255,${0.35 * solvedGlow})`;
      ctx.fillRect(x, y, t.w, t.h);
    }
    ctx.restore();
  }

  function drawFlyingSegment(anim) {
    if (!anim) return;
    const from = layout.tubes[anim.from];
    const to = layout.tubes[anim.to];
    if (!from || !to) return;
    const fromTopY = from.y + from.h - anim.fromCountAtStart * from.segH;
    const toTopY = to.y + to.h - (anim.toCountAtStart + anim.count) * to.segH;
    const x = from.x + from.w / 2 + (to.x + to.w / 2 - (from.x + from.w / 2)) * anim.t;
    const arc = -Math.sin(anim.t * Math.PI) * 40;
    const y = fromTopY + (toTopY - fromTopY) * anim.t + arc;
    ctx.save();
    ctx.fillStyle = PALETTE[anim.color];
    roundedRectPath(ctx, x - from.w * 0.32, y, from.w * 0.64, anim.segH * anim.count, 6);
    ctx.fill();
    ctx.restore();
  }

  function draw({ tubes, selected, particles, anim, shake, solvedFlash }) {
    ctx.clearRect(0, 0, cssW, cssH);
    const shakeX = shake ? (Math.random() - 0.5) * shake : 0;
    const shakeY = shake ? (Math.random() - 0.5) * shake : 0;

    tubes.forEach((tube, i) => {
      let dim = 0;
      if (anim && anim.from === i) dim = anim.count;
      drawTube(layout.tubes[i], tube, {
        selected: selected === i,
        dimTopCount: dim,
        shakeX, shakeY,
        solvedGlow: solvedFlash && solvedFlash[i] ? solvedFlash[i] : 0
      });
    });

    drawFlyingSegment(anim);
    if (particles) particles.draw(ctx);
  }

  return { resize, draw, hitTest, getLayout: () => layout };
}
