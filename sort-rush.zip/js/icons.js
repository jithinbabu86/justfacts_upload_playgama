// Hand-authored SVG icon set - replaces emoji glyphs (which render inconsistently across
// platforms and read as an unstyled default) with a single, consistent, colorable visual
// language. All use viewBox 0 0 24 24 and currentColor so CSS controls tint per context.

const svg = (body, extra = '') => `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" ${extra}>${body}</svg>`;

export const ICONS = {
  speakerOn: svg(`
    <path d="M4 9v6h4l5 5V4L8 9H4z" fill="currentColor"/>
    <path d="M16.5 9a4 4 0 0 1 0 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
    <path d="M19 6.5a8 8 0 0 1 0 11" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" opacity="0.7"/>
  `),
  speakerOff: svg(`
    <path d="M4 9v6h4l5 5V4L8 9H4z" fill="currentColor"/>
    <path d="M16 9l5.5 6M21.5 9L16 15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
  `),
  restart: svg(`
    <path d="M4 4v5h5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M4.6 15a8 8 0 1 0 1.5-8.4L4 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  `),
  undo: svg(`
    <path d="M9 8 4 12l5 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M4 12h9.5a5.5 5.5 0 1 1 0 11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  `),
  hint: svg(`
    <path d="M9 21h6M10 18h4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
    <path d="M12 3a6.5 6.5 0 0 0-3.8 11.8c.5.4.8 1 .8 1.7v.5h6v-.5c0-.7.3-1.3.8-1.7A6.5 6.5 0 0 0 12 3z" fill="currentColor"/>
  `),
  flask: svg(`
    <path d="M9 3h6M10 3v6.5L6.5 17a2 2 0 0 0 1.8 3h7.4a2 2 0 0 0 1.8-3L14 9.5V3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M8.2 15.5h7.6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
    <circle cx="12" cy="18" r="1.1" fill="currentColor"/>
  `),
  trophy: svg(`
    <path d="M7 4h10v5a5 5 0 0 1-10 0V4z" fill="currentColor"/>
    <path d="M7 5H4a3 3 0 0 0 3 5M17 5h3a3 3 0 0 1-3 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    <path d="M10 15.5h4v2a2 2 0 0 1 2 2v.5H8v-.5a2 2 0 0 1 2-2v-2z" fill="currentColor"/>
  `),
  gem: svg(`
    <path d="M6 3h12l4 5-10 13L2 8l4-5z" fill="currentColor"/>
    <path d="M2 8h20M9 3l-2 5 5 13 5-13-2-5" stroke="rgba(0,0,0,0.18)" stroke-width="1"/>
  `),
  flame: svg(`
    <path d="M12 2c1 3-3 4-3 8a3 3 0 0 0 6 0c0-1-1-1.5-.5-3 1.5 1 3.5 3.5 3.5 6.5A6 6 0 0 1 6 13.5C6 8 12 6 12 2z" fill="currentColor"/>
  `),
  target: svg(`
    <circle cx="12" cy="12" r="9" fill="currentColor" opacity="0.25"/>
    <circle cx="12" cy="12" r="6" fill="currentColor" opacity="0.55"/>
    <circle cx="12" cy="12" r="3" fill="currentColor"/>
  `)
};

export function renderIcon(name) {
  return ICONS[name] || '';
}

export function mountIcons(root = document) {
  root.querySelectorAll('[data-icon]').forEach((el) => {
    el.innerHTML = renderIcon(el.dataset.icon);
  });
}
