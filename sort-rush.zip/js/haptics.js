// Thin wrapper around navigator.vibrate - not all mobile browsers support it (notably iOS
// Safari), so every call is best-effort and silently ignored where unsupported.

const supported = typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function';

function vibrate(pattern) {
  if (!supported) return;
  try { navigator.vibrate(pattern); } catch { /* ignore */ }
}

export const haptics = {
  tap: () => vibrate(10),
  pour: () => vibrate(15),
  solved: () => vibrate([0, 20, 40, 20]),
  levelComplete: () => vibrate([0, 30, 50, 30, 50, 60]),
  invalid: () => vibrate(25)
};
